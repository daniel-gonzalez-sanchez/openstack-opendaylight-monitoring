#! /bin/bash

polling(){

  UPTIME=$(snmpget -v1 -c public $1 hrSystemUptime.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #BYTESIN=$(snmpget -v1 -c public $1 ifInOctets.2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #BYTESOUT=$(snmpget -v1 -c public $1 ifOutOctets.2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  LOADCPU1=$(snmpget -v1 -c public $1 laLoad.1 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  LOADCPU2=$(snmpget -v1 -c public $1 laLoad.2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  LOADCPU3=$(snmpget -v1 -c public $1 laLoad.3 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  SYSTEMPROCESS=$(snmpget -v1 -c public $1 hrSystemProcesses.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  NUMUSERS=$(snmpget -v1 -c public $1 hrSystemNumUsers.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  MEMRAMAVAIL=$(snmpget -v1 -c public $1 memAvailReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  MEMRAMTOTAL=$(snmpget -v1 -c public $1 memTotalReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')

  #DISKINDEX=$(snmpwalk -v 2c -c public $1 dskIndex | awk '{{printf $NF " "} ; printf "\n"}')
  #numparticiones=`echo $DISKINDEX | awk '{print $NF}'`

  IFINDEX=$(snmpwalk -v 2c -c public $1 ifIndex | awk '{{printf $NF " "} ; printf "\n"}')
  numifaces=`echo "$IFINDEX" | wc -l`

  cont=0

  echo "Host IP: "$1

  SYSUPTIME=`echo $UPTIME | awk '{ print $NF }'`
  echo "System Up Time: "$SYSUPTIME

  #echo "Disk: "

  #for((i=1;i<=$numparticiones;i++))do
  #      particiones[$i]=$i;
  #done

  #for((j=1;j<=$numparticiones;j++))do
  #     echo $(snmpwalk -v 2c -c public $1 dskPath.${particiones[$j]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') " Total: " $(snmpwalk -v 2c -c public localhost dskTotal.${particiones[$j]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') " Available: " $(snmpwalk -v 2c -c public localhost dskAvail.${particiones[$j]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') " Used(%): " $(snmpwalk -v 2c -c public $1 dskPercent.${particiones[$j]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #done

  #echo "Interfaces traffic: "
  for line in $IFINDEX; do
        interfaces[$cont]=$line ;
        let "cont++" ;
  done

  for((k=0;k<$numifaces;k++))do
       #echo ${interfaces[$k]} ;
       BYTESIN=$(snmpget -v 2c -c public $1 ifInOctets.${interfaces[$k]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') ;
       BYTESOUT=$(snmpget -v 2c -c public $1 ifOutOctets.${interfaces[$k]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') ;
       #echo $(snmpget -v 2c -c public $1 ifDescr.${interfaces[$k]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') ;
       echo "Bytes In (" $(snmpget -v 2c -c public $1 ifDescr.${interfaces[$k]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') "):" $BYTESIN
       echo "Bytes Out (" $(snmpget -v 2c -c public $1 ifDescr.${interfaces[$k]} | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}') "):" $BYTESOUT
       #echo ""
  done

  #echo "Bytes in: "$BYTESIN
  #echo "Bytes out: "$BYTESOUT

  echo "CPU Load (%): "$LOADCPU1"," $LOADCPU2"," $LOADCPU3

#  for((i=1;i<=$SYSTEMPROCESS;i++))do
#        procesos[$i]=$(echo $PIDS | cut -d' ' -f$i);
#  done

  echo "System Processes: "$SYSTEMPROCESS
  echo "Current users: "$NUMUSERS
  echo "RAM available: "$MEMRAMAVAIL
  echo "RAM total: "$MEMRAMTOTAL
  MEMRAMAVAIL=`echo $MEMRAMAVAIL | awk '{ print $1 }'`
  MEMRAMTOTAL=`echo $MEMRAMTOTAL | awk '{ print $1 }'`
  #MEMRAMUSED=`expr $MEMRAMTOTAL - $MEMRAMAVAIL`
  #RAM=$(echo "scale=2; $MEMRAMUSED*100/$MEMRAMTOTAL" | bc)
  RAMUNUSED=$(echo "scale=2; $MEMRAMAVAIL*100/$MEMRAMTOTAL" | bc)
  echo "RAM unused (%): "$RAMUNUSED

#  echo " "

}

#MAIN:
polling $1

