#! /bin/bash

polling(){

  LOADCPU1=$(snmpget -v1 -c public $1 laLoad.1 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  LOADCPU2=$(snmpget -v1 -c public $1 laLoad.2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  LOADCPU3=$(snmpget -v1 -c public $1 laLoad.3 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #SYSTEMPROCESS=$(snmpget -v1 -c public $1 hrSystemProcesses.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')

  #MEMRAMAVAIL=$(snmpget -v1 -c public $1 memAvailReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #MEMRAMTOTAL=$(snmpget -v1 -c public $1 memTotalReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #PIDS=$(snmpwalk -v 2c -c public $1 hrSWRunIndex | awk '{{printf $NF " "} ; printf "\n"}')

  PIDSWITCHOVS=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "ovs-vswitchd"| awk '{printf $1 " "}')
  PIDSWITCHOVS=`echo $PIDSWITCHOVS | awk -F "." '{ print $NF }'`
  #PIDSMONITOR=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "monitor"| awk '{printf $1 " "}')

  #PIDMONITOR1=`echo $PIDSMONITOR | awk '{ print $1 }'`
  #PIDMONITOR1=`echo $PIDMONITOR1 | awk -F "." '{ print $NF }'`
  #PIDMONITOR2=`echo $PIDSMONITOR | awk '{ print $NF }'`
  #PIDMONITOR2=`echo $PIDMONITOR2 | awk -F "." '{ print $NF }'`

  PIDOVSDBSERVER=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "ovsdb-server"| awk '{printf $1 " "}')
  PIDOVSDBSERVER=`echo $PIDOVSDBSERVER | awk -F "." '{ print $NF }'`

  PIDNRPE=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "nrpe"| awk '{printf $1 " "}')
  PIDNRPE=`echo $PIDNRPE | awk -F "." '{ print $NF }'`

  PIDSNMPD=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "snmpd"| awk '{printf $1 " "}')
  PIDSNMPD=`echo $PIDSNMPD | awk -F "." '{ print $NF }'`

  echo "->Host IP: "$1

  echo " "

  echo "Current CPU load average: "$LOADCPU1"," $LOADCPU2"," $LOADCPU3

  echo "CPU load average in last 1 min: "$LOADCPU1

  echo "CPU load average in last 5 min: "$LOADCPU2

  echo "CPU load average in last 15 min: "$LOADCPU3

  #for((i=1;i<=$SYSTEMPROCESS;i++))do
  #      procesos[$i]=$(echo $PIDS | cut -d' ' -f$i);
  #done


if [ -n "$PIDSWITCHOVS" ]
then 
  echo " "
  CPUSWITCHOVS=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDSWITCHOVS | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "PID ovs-switchd: "$PIDSWITCHOVS
  echo "CPU TIME ovs-switchd: "$CPUSWITCHOVS" cseg"
  CPULOAD1=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDSWITCHOVS)
  echo $CPULOAD1
fi
  
if [ -n "$PIDOVSDBSERVER" ]
then 
  echo " "
  echo "PID ovsdb-server: "$PIDOVSDBSERVER
  CPUOVSDBSERVER=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDOVSDBSERVER | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "CPU TIME ovsdb-server: "$CPUOVSDBSERVER " cseg"
  CPULOAD2=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDOVSDBSERVER)
  echo $CPULOAD2
fi
  #echo " "

  #echo "PID monitor 1: "$PIDMONITOR1
  #CPUMONITOR1=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDMONITOR1 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #echo "CPU TIME monitor 1: "$CPUMONITOR1 " cseg"
  #CPULOAD7=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDMONITOR1)
  #echo $CPULOAD7

  #echo " "

  #echo "PID monitor 2: "$PIDMONITOR2
  #CPUMONITOR2=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDMONITOR2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  #echo "CPU TIME monitor 2: "$CPUMONITOR2 " cseg"
  #CPULOAD4=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDMONITOR2)
  #echo $CPULOAD4

  echo " "

  echo "PID nagios-nrpe-server: "$PIDNRPE
  CPUNRPE=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDNRPE | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "CPU TIME nagios-nrpe-server: "$CPUNRPE " cseg"
  CPULOAD5=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDNRPE)
  echo $CPULOAD5

  echo " "

  echo "PID snmpd: "$PIDSNMPD
  CPUSNMPD=$(snmpwalk -v 2c -c public $1 hrSWRunPerfCPU.$PIDSNMPD | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "CPU TIME snmpd: "$CPUSNMPD " cseg"
  CPULOAD6=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_cpu -a $PIDSNMPD)
  echo $CPULOAD6

  echo " "
}

#MAIN:
polling $1

