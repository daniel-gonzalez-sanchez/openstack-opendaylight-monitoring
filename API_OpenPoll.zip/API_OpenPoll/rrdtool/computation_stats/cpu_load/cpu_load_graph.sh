#! /bin/sh

RRDATAFILE="$(pwd)"/rrd_files/$3

if [ $# -lt 2 ]; then
  echo "Faltan los momentos de inicio y fin. Ej. (end-6h now)"
  exit 0
else
  rrdtool graph "$(pwd)"/images/$4 --imgformat PNG \
  --start $1 --end $2 \
  --title "CPU LOAD STATISTICS" \
  --vertical-label "CPU Load (%)" \
  --watermark "`date`" \
  --rigid \
  --width 500 --height 250 \
  --alt-autoscale \
  DEF:dl1=$RRDATAFILE:l1:AVERAGE \
  DEF:dl2=$RRDATAFILE:l2:AVERAGE \
  DEF:dl3=$RRDATAFILE:l3:AVERAGE \
  CDEF:load1=dl1 \
  CDEF:load2=dl2 \
  CDEF:load3=dl3 \
  LINE1:load1#0000FF:"Load 1"\
  LINE1:load3#00FF00:"Load 15 \n"\
  LINE1:load2#FF0000:"Load 5"
fi

exit 0
