#! /bin/sh
# Script para crear base de datos RRD para monitoreo de carga de CPU

# Directorio de la base de datos
RRDATADIR="$(pwd)"/rrd_files

# Archivo de la base de datos
RRDATAFILE=$4

# Crear directorio si no existe
mkdir -p $RRDATADIR

# Crear base de datos, si no existe
if [ ! -f "$RRDATADIR/$RRDATAFILE" ]; then

  rrdtool create "$RRDATADIR/$RRDATAFILE" \
  --step 1 \
  DS:l1:GAUGE:20:U:U \
  DS:l2:GAUGE:20:U:U \
  DS:l3:GAUGE:20:U:U \
  RRA:AVERAGE:0.5:3:8640 \
  RRA:AVERAGE:0.5:30:25920 \
  RRA:AVERAGE:0.5:720:4380
  #elif [ $4 -eq 0 ]
  #then
  else
  	RRDATAFILE=$RRDATADIR/$RRDATAFILE
 	  LOAD1=$1;
  	LOAD2=$2;
  	LOAD3=$3;
  	rrdtool update $RRDATAFILE N:$LOAD1:$LOAD2:$LOAD3
fi

exit 0
