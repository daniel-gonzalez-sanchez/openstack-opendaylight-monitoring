#! /bin/bash

polling(){

  MEMRAMAVAIL=$(snmpget -v1 -c public $1 memAvailReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  MEMRAMTOTAL=$(snmpget -v1 -c public $1 memTotalReal.0 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  PIDS=$(snmpwalk -v 2c -c public $1 hrSWRunIndex | awk '{{printf $NF " "} ; printf "\n"}')

  PIDSWITCHOVS=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "ovs-vswitchd"| awk '{printf $1 " "}')
  PIDSWITCHOVS=`echo $PIDSWITCHOVS | awk -F "." '{ print $NF }'`
  #PIDSMONITOR=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "monitor"| awk '{printf $1 " "}')

  #PIDMONITOR1=`echo $PIDSMONITOR | awk '{ print $1 }'`
  #PIDMONITOR1=`echo $PIDMONITOR1 | awk -F "." '{ print $NF }'`
  #PIDMONITOR2=`echo $PIDSMONITOR | awk '{ print $NF }'`
  #PIDMONITOR2=`echo $PIDMONITOR2 | awk -F "." '{ print $NF }'`

  PIDOVSDBSERVER=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "ovsdb-server"| awk '{printf $1 " "}')
  PIDOVSDBSERVER=`echo $PIDOVSDBSERVER | awk -F "." '{ print $NF }'`

  PIDNRPE=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "nrpe"| awk '{printf $1 " "}')
  PIDNRPE=`echo $PIDNRPE | awk -F "." '{ print $NF }'`

  PIDSNMPD=$(snmpwalk -v 2c -c public $1 .1.3.6.1.2.1.25.4.2.1.2 | grep "snmpd"| awk '{printf $1 " "}')
  PIDSNMPD=`echo $PIDSNMPD | awk -F "." '{ print $NF }'`


  echo "->Host IP: "$1

  echo " "

  echo "Memory RAM available: "$MEMRAMAVAIL
  echo "Memory RAM total: "$MEMRAMTOTAL
  MEMRAMAVAIL=`echo $MEMRAMAVAIL | awk '{ print $1 }'`
  MEMRAMTOTAL=`echo $MEMRAMTOTAL | awk '{ print $1 }'`
  RAMUNUSED=$(echo "scale=2; $MEMRAMAVAIL*100/$MEMRAMTOTAL" | bc)
  #MEMRAMUSED=`expr $MEMRAMTOTAL - $MEMRAMAVAIL`
  #RAM=$(echo "scale=2; $MEMRAMUSED*100/$MEMRAMTOTAL" | bc)
  echo "Total RAM unused (%): "$RAMUNUSED

if [ -n "$PIDSWITCHOVS" ]
then 
  echo " "
  echo "PID ovs-switchd: "$PIDSWITCHOVS
  MEMSWITCHOVS=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDSWITCHOVS | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "Memory ovs-switchd: "$MEMSWITCHOVS
  MEMUSAGE1=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDSWITCHOVS)
  echo $MEMUSAGE1
fi

if [ -n "$PIDSWITCHOVS" ]
then 
  echo " "

  echo "PID ovsdb-server: "$PIDOVSDBSERVER
  MEMOVSDBSERVER=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDOVSDBSERVER | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "Memory ovsdb-server: "$MEMOVSDBSERVER
  MEMUSAGE2=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDOVSDBSERVER)
  echo $MEMUSAGE2
fi

#  echo " "

#  echo "PID monitor 1: "$PIDMONITOR1
#  MEMMONITOR1=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDMONITOR1 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
#  echo "Memory monitor 1: "$MEMMONITOR1
#  MEMUSAGE7=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDMONITOR1)
#  echo $MEMUSAGE7

#  echo " "

#  echo "PID monitor 2: "$PIDMONITOR2
#  MEMMONITOR2=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDMONITOR2 | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
#  echo "Memory monitor 2: "$MEMMONITOR2
#  MEMUSAGE4=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDMONITOR2)
#  echo $MEMUSAGE4

  echo " "

  echo "PID nagios-nrpe-server: "$PIDNRPE
  MEMNRPE=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDNRPE | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "Memory nagios-nrpe-server: "$MEMNRPE
  MEMUSAGE5=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDNRPE)
  echo $MEMUSAGE5

  echo " "

  echo "PID snmpd: "$PIDSNMPD
  MEMSNMPD=$(snmpwalk -v 2c -c public $1 hrSWRunPerfMem.$PIDSNMPD | awk '{for(i=4;i<=NF;i++) {printf $i " "} ; printf "\n"}')
  echo "Memory snmpd: "$MEMSNMPD
  MEMUSAGE6=$(/usr/lib/nagios/plugins/check_nrpe -H $1 -c check_proc_mem -a $PIDSNMPD)
  echo $MEMUSAGE6

  echo " "

}

#MAIN:
polling $1

