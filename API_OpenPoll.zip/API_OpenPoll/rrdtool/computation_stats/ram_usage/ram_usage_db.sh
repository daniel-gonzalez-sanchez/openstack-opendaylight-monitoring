#! /bin/sh
# Script para crear base de datos RRD para monitoreo de uso de RAM

# Directorio de la base de datos
RRDATADIR="$(pwd)"/rrd_files

# Archivo de la base de datos
RRDATAFILE=$2

# Crear directorio si no existe
mkdir -p $RRDATADIR

# Crear base de datos, si no existe
if [ ! -f "$RRDATADIR/$RRDATAFILE" ]; then

  rrdtool create "$RRDATADIR/$RRDATAFILE" \
  --step 1 \
  DS:usg:GAUGE:20:U:U \
  RRA:AVERAGE:0.5:3:8640 \
  RRA:AVERAGE:0.5:30:25920 \
  RRA:AVERAGE:0.5:720:4380
  #elif [ $2 -eq 0 ]
  #then
  else
  	RRDATAFILE=$RRDATADIR/$RRDATAFILE
  	USAGE=$1;
  	rrdtool update $RRDATAFILE N:$USAGE
fi

exit 0
