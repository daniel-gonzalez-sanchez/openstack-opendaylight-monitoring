#! /bin/sh

RRDATAFILE="$(pwd)"/rrd_files/$3

if [ $# -lt 2 ]; then
  echo "Faltan los momentos de inicio y fin. Ej. (end-6h now)"
  exit 0
else
  rrdtool graph "$(pwd)"/images/$4 --imgformat PNG \
  --start $1 --end $2 \
  --title "RAM USAGE STATISTICS" \
  --vertical-label "RAM unused (%)" \
  --watermark "`date`" \
  --rigid \
  --width 500 --height 250 \
  --alt-autoscale \
  DEF:dusg=$RRDATAFILE:usg:AVERAGE \
  CDEF:usage=dusg \
  LINE1:usage#0000FF:"RAM unused (%)\n"
fi

exit 0
