#! /bin/sh

RRDATAFILE="$(pwd)"/rrd_files/$3

# Directorio de las imagenes
IMGDIR="$(pwd)"/images

# Crear directorio si no existe
mkdir -p $IMGDIR

if [ $# -lt 2 ]; then
  echo "Faltan los momentos de inicio y fin. Ej. (end-6h now)"
  exit 0
else
  rrdtool graph $IMGDIR/$4 --imgformat PNG \
  --start $1 --end $2 \
  --title "TRAFFIC STATISTICS" \
  --vertical-label "Byte Rate (bytes/s)" \
  --watermark "`date`" \
  --rigid \
  --width 500 --height 250 \
  --alt-autoscale \
  DEF:dsin=$RRDATAFILE:in:AVERAGE \
  DEF:dsout=$RRDATAFILE:out:AVERAGE \
  CDEF:download=dsin \
  CDEF:upload=dsout \
  LINE1:download#0000FF:"Byte rate transmitted \n" \
  LINE1.5:upload#FF0000:"Byte rate received"
fi

exit 0
