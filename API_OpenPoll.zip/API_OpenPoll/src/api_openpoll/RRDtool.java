package api_openpoll;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 * Clase con el hilo de ejecución para representar la gráfica RRDtool con una
 * métrica concreta de monitorización. Desde la GUI_Graph correspondiente, se
 * instancia un objeto de esta clase para representar la gráfica RRDtool dentro
 * de una etiqueta JLabel de la GUI. Mientras no se indique lo contrario desde
 * la GUI, la gráfica se irá refrescando según los datos monitorizados de la red
 * denotados en el archivo .rrd, la imagen de la gráfica generada
 * correspondientes y el tiempo de refresco indicado desde la GUI_Topology.
 *
 * @author Daniel González Sánchez
 */
public class RRDtool extends Thread {

    /**
     * Atributo para almacenar el tiempo de refresco que tendrá la gráfica de
     * monitorización para que se vaya actualizando. El tiempo de refresco o
     * refresh time.
     */
    private int time;

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Atributo con el path del fichero donde se encuentra el archivo con la
     * imagen RRDtool donde se encuentran las gráficas a representar.
     */
    private String img;

    /**
     * Atributo con el path del fichero de texto con los datos monitorizados de
     * la red.
     */
    private String datos;

    /**
     * Atributo String con el título para la GUI y gráfica RDDTOOL.
     */
    private String title;

    /**
     * Atributo objeto de la clase JLabel. En esta etiqueta es donde recogeremos
     * la clase BufferedImage con el archivo de la imagen .png de la gráfica
     * RRDtool actualizada para luego representarla en la GUI_Graph.
     */
    private JLabel label;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton btStopRRD;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton btStopPoll;

    /**
     * Atributo objeto de la clase GUI_Graph.
     */
    private GUI_Graph graph;

    /**
     * Constructor por defecto.
     */
    public RRDtool() {
        cerrar = false;
    }

    /**
     * Constructor parametrizado.
     *
     * @param time
     * @param img
     * @param datos
     * @param title
     * @param label
     * @param btStopRRD
     * @param graph
     * @param btStopPoll
     */
    public RRDtool(int time, String img, String datos, String title, JLabel label, JButton btStopRRD, GUI_Graph graph, JButton btStopPoll) {
        this.time = time;
        this.img = img;
        this.datos = datos;
        this.title = title;
        this.label = label;
        this.btStopRRD = btStopRRD;
        this.graph = graph;
        this.btStopPoll = btStopPoll;
    }

    @Override
    public void run() {

        //Archivo .png con la imagen de la gráfica generada por RRDtool:
        String file = img;

        /*
        Variable booleana para remarcar cúando se comienza a representar la métrica
        de monitorización en cuestión. Servirá para que en la primera medida o muestra
        la GUI_Graph con la gráfica se visualice o imprima en el centro de la pantalla
        con el método graph.setLocationRelativeTo(null). En medidas posteriores ya no
        se centrará la gráfica gracias a esta variable.
         */
        boolean inicio = true;
        File f = new File(file);
        BufferedImage imagen;

        try {
            //Mientras el usuario no cierre el GUI_Graph el hilo de ejecución seguirá activo:
            while (cerrar == false) {
                if (f.exists() && f.canRead()) {
                    try {
                        //Recogemos el archivo de la imagen .png de la gráfica en un objeto de tipo BufferedImage:
                        imagen = ImageIO.read(f);

                        if (imagen != null) {
                            imagen.flush();
                            Image ima = imagen.getScaledInstance(label.getWidth(), label.getHeight(), Image.SCALE_DEFAULT);
                            label.setIcon(new ImageIcon(ima));
                        }
                    } catch (IOException ex) {
                        Logger.getLogger(RRDtool.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                /*
                Si se pulsa el botón Stop Polling de la GUI_Topology, se cerrará la ventana y se dejará de
                mostrar la información concreta monitorizada parando el hilo de ejecución (cerrar = true).
                 */
                btStopPoll.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (e.getSource().equals(btStopPoll)) {
                            cerrar = true;
                        }
                    }
                });


                /*
                Si pulsamos el botón Stop de la GUI_Graph, se borrará el JLabel de la GUI y se dejará de
                mostrar la gráfica de monitorización de información determinada parando el hilo de ejecución (cerrar = true).
                 */
                btStopRRD.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (e.getSource().equals(btStopRRD)) {
                            cerrar = true;
                        }
                    }
                });

                /*
                Si pulsamos la X de cierre de la GUI_Graph, se cerrará la ventana y se dejará de
                mostrar la información concreta monitorizada parando el hilo de ejecución (cerrar = true).
                 */
                graph.addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent evt) {
                        cerrar = true;
                    }
                });

                //Sleep para simular el tiempo de refresco:
                Thread.sleep(time * 1000);
            }

        } catch (Exception e) {
            System.err.println(e);
        }
    }

}
