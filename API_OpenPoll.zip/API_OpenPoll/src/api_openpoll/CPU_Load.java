package api_openpoll;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Esta clase se encargará de monitorizar la carga de CPU de cada host vinculado
 * a la infraestructura de red OpenStack SDN. Generará un informe detallado con
 * el consumo de recursos registrado y una gráfica RRDTool para la carga de CPU
 * en tanto por ciento registrada en los últimos minutos.
 *
 * @author Daniel González Sánchez
 */
public class CPU_Load {

    /**
     * Atributo donde almacenar en cada momento la carga de CPU media ponderada
     * en el último minuto (en tanto por ciento %) del host en concreto
     * (identificado por la IP pasada por parámetro). Parte de la medida de
     * cómputo de los hosts.
     */
    private float load1;

    /**
     * Atributo donde almacenar en cada momento la carga de CPU media ponderada
     * en los últimos 5 minutos (en tanto por ciento %) del host en concreto
     * (identificado por la IP pasada por parámetro). Parte de la medida de
     * cómputo de los hosts.
     */
    private float load5;

    /**
     * Atributo donde almacenar en cada momento la carga de CPU media ponderada
     * en los últimos 15 minutos (en tanto por ciento %) del host en concreto
     * (identificado por la IP pasada por parámetro). Parte de la medida de
     * cómputo de los hosts.
     */
    private float load15;

    /**
     * Atributo donde almacenar las direcciones IP del host en el que vamos a
     * monitorizar la carga de CPU (%).
     */
    private ArrayList<String> ip_hosts;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Constructor por defecto.
     */
    public CPU_Load() {
        load1 = 0;
        load5 = 0;
        load15 = 0;
        cerrar = false;
    }

    /**
     * Constructor parametrizado.
     *
     * @param time
     * @param ip_hosts
     */
    public CPU_Load(int time, ArrayList<String> ip_hosts) {
        this.time = time;
        this.ip_hosts = ip_hosts;
    }

    /**
     * Método con la lógica de monitorización para extraer las métricas de
     * capacidades de cómputo de los hosts de gestión de la infraestructura de
     * red OpenStack ("controller", "network", "compute1", "compute2" y
     * "opendaylight") relacionadas con la carga de CPU y consumo de recursos.
     *
     * En primer lugar, este método se encarga de lanzar la ejecución de un
     * Shell Script desarrollado para realizar consultas desde la máquina
     * servidora a los hosts de la red mediante el protocolo SNMP y la utilidad
     * NRPE de Nagios para obtener datos significativos sobre la carga de CPU.
     * Este script es gestor_cpu_load.sh y se encuentra en el subdirectorio
     * ../rrdtool/computation_stats/cpu_load/ del proyecto. El script será
     * lanzado desde la aplicación Java con el método
     * Runtime.getRuntime().exec().
     *
     * El contenido monitorizado en cada muestra será almacenado en un
     * StringBuilder el cual se sobrescribirá en un fichero de texto del
     * directorio ../rrdtool/computation_stats/cpu_load/data_info/. Unos de los
     * parámetros monitorizados desde el shell script desarrollado es la carga
     * general de CPU en tanto por ciento del host consultado. Este parámetro en
     * concreto será el dato que se representará en la gráfica RRDTOOL.
     *
     * De esta forma ya podremos generar el archivo RRDTOOL con la información
     * obtenida. Lo primero será crear la base de datos circular propia de
     * RRDTOOL (Round Robin Database) siempre que no exista (archivo .rrd). Una
     * vez generada, se irá actualizando con los valores que se vayan obteniendo
     * por cada muestra. (Comentar que el paso o toma de datos en la Base de
     * Datos está definida en un mínimo de 1 segundo). Por último, se genera el
     * archivo con la imagen de la gráfica RRDTOOL según los valores registrados
     * en la base de datos a una escala e intervalo de tiempo determinada (se
     * irán mostrando los datos registrados durante los 10 últimos minutos). Las
     * funciones de creación, actualización de la base de datos RRDTOOL y la
     * generación de la gráfica están desarrolladas en 2 shell scripts
     * diferentes que se encuentra en el la carpeta del proyecto API_OpenPoll,
     * en el subdirectorio ../rrdtool/computation_stats/cpu_load/. Por tanto, en
     * ese directorio se generarán la imagen de la gráfica RRDTOOL en formato
     * .png y el archivo de la base de datos circular .rrd. Estos scripts serán
     * lanzados desde java con el método Runtime.getRuntime().exec().
     *
     * Recordar que el fichero de datos con los parámetros monitorizados y la
     * imagen con la gráfica RRDTOOL que se vaya generando serán accedidos
     * posteriormente desde la clase GUI_Graph para así poder obtener
     * información de la estadísticas y gráficas de monitorización en tiempo
     * real.
     *
     */
    public void monitoring() {

        //Directorio del proyecto:
        File dir = new File("../API_OpenPoll");

        Ficheros f = new Ficheros();

        try {
            //Monitorizamos el consumo de CPU de cada host recogido del ArrayList:
            for (int m = 0; m < ip_hosts.size(); m++) {
                String ip = ip_hosts.get(m);

                //Archivo .png con la imagen de la gráfica generada por RRDTOOL:
                String image = "../API_OpenPoll/rrdtool/computation_stats/cpu_load/images/cpu_load_" + ip + ".png";

                //Lanzamos el Shell Script para monitorizar la carga de CPU:
                String[] script = {"/bin/sh", "-c", "cd " + "../API_OpenPoll/rrdtool/computation_stats/cpu_load; ./gestor_cpu_load.sh " + ip};
                Process process = null;
                StringBuilder data_info = new StringBuilder();
                try {
                    process = Runtime.getRuntime().exec(script);
                    InputStream input = process.getInputStream();
                    BufferedInputStream buffer = new BufferedInputStream(input);
                    int i = 0;
                    while ((i = buffer.read()) != -1) {
                        data_info.append((char) i);
                    }
                    buffer.close();
                    input.close();
                } catch (IOException ex) {
                    Logger.getLogger(GUI_Topology.class.getName()).log(Level.SEVERE, null, ex);
                }

                String fichero = "../API_OpenPoll/rrdtool/computation_stats/cpu_load/data_info/cpu_load_" + ip + ".txt";
                f.escribirFichero(fichero, data_info.toString());

                String cpu_loads = f.leerFicheroCPU(fichero);
                String[] split = cpu_loads.split(" , ");
                load1 = Float.parseFloat(split[0]);
                load5 = Float.parseFloat(split[1]);
                load15 = Float.parseFloat(split[2]);

                /*
                    Lanzamos el script de creación y actualización de la base de datos RRDTOOL.
                    Recibirá por parámetro la métrica de cargas de CPU medias obtenidas en 
                    los últimos 1, 5 y 15 minutos.
                 */
                String[] createDatabase = {"/bin/sh", "-c", "cd " + dir.getPath() + "/rrdtool/computation_stats/cpu_load; ./cpu_load_db.sh " + load1 + " " + load5 + " " + load15 + " " + "cpu_load_db_" + ip + ".rrd"};
                Process p2 = Runtime.getRuntime().exec(createDatabase);

                /*
                    Lanzamos el script para generar la gráfica RRDTOOL con los datos de la base de datos RRDTOOL
                    actualizados.
                 */
                String[] grafico = {"/bin/sh", "-c", "cd " + dir.getPath() + "/rrdtool/computation_stats/cpu_load; ./cpu_load_graph.sh end-600s now " + "cpu_load_db_" + ip + ".rrd" + " " + "cpu_load_" + ip + ".png"};
                Process p4 = Runtime.getRuntime().exec(grafico);
            }
        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }

    }

}
