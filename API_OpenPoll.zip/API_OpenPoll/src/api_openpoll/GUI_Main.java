package api_openpoll;

import java.awt.Cursor;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * La clase GUI_Main es la GUI inicial del programa para poner en funcionamiento
 * la herramienta de monitorización "OpenPoll: Open Polling from OpenStack and
 * OpenDayLight integration infrastructures".
 *
 * Esta herramienta consiste en una aplicación para la monitorización de
 * infraestructuras de redes SDN en entornos Cloud a través de consultas
 * mediante la API REST propia del controlador SDN OpenDayLight, así como
 * utilizando el protocolo SNMP y el servicio NRPE de Nagios. La aplicación se
 * conectará con el controlador OpenDayLight de la red SDN a través de la API
 * REST. Esta API realizará peticiones HTTP (mediante sockets TCP) para extraer
 * información y monitorizar el estado de la red. A través de SNMP y Nagios (en
 * concreto su plugin NRPE), se monitorizará el consumo de CPU y RAM de los
 * dispositivos o hosts finales de despliegue y gestión de la infraestructura
 * OpenStack (estudio de cómputo).
 *
 * El programa consta de una interfaz gráfica de usuario (GUI) para que el
 * usuario elija las diferentes opciones del programa y para poder visualizar
 * los datos monitorizados de la red.
 *
 * Se visualizarán gráficos con datos monitorizados correspondientes a métricas
 * o estadísticas de flujos y puertos de cada switch Open vSwitch del plano de
 * datos SDN y en base al estudio de cómputo de los dispositivos finales (hosts)
 * de la infraestructura de red OpenStack.
 *
 * Para poner en funcionamiento la aplicación, el usuario deberá de introducir
 * la dirección IP y puerto del controlador OpenDayLight para conectarse a él a
 * partir de la API REST y así poder empezar a realizar peticiones HTTP para
 * realizar la labor de monitorización de los OVSwitches Datapath de la red SDN.
 *
 * @author Daniel González Sánchez
 */
public class GUI_Main extends javax.swing.JFrame {

    /**
     * Atributo objeto de la clase SwitchStats.
     */
    private SwitchStats sw_stats;

    /**
     * Atributo entero donde almacenar el número de switches que contiene
     * nuestra topología de red.
     */
    private int num_switches;

    /**
     * Atributo vector de Strings con la lista de switches existentes en la
     * topología de red (almacena el identificador de los OVS).
     */
    private String[] list_switches;

    /**
     * Atributo vector de String donde almacenaremos el número de puertos que
     * contiene cada switch de nuestra topología. Cada posición del vector
     * contendrá el número de puertos correspondientes a cada switch de la red.
     * (Asociamos la posición con el número del switch en orden creciente: Ej.
     * puertos_switches[0] contendrá el número de puertos asociados al primer
     * switch ...).
     */
    private String[] num_ports_switches;

    /**
     * Atributo matriz de String donde almacenaremos la lista de nombres de los
     * puertos de cada switch de la topología de red. Cada posición de la matriz
     * contendrá el nombre asociado a cada puerto de cada switch de la red.
     * (Asociamos la fila con el número del switch y la columna con el nombre de
     * puerto en orden creciente: Ej. name_ports_switches[0][0] contendrá el
     * nombre del primer puerto asociado al primer switch...).
     */
    private String[][] name_ports_switches;

    /**
     * Atributo matriz de String donde almacenaremos la lista de identificadores
     * o número de los puertos de cada switch de la topología de red. Cada
     * posición de la matriz contendrá el identificador de cada puerto asociado
     * a cada switch de la red. (Asociamos la fila con el número del switch y la
     * columna con el identificador de puerto en orden creciente: Ej.
     * list_ports_switches[0][0] contendrá el identificador del primer puerto
     * asociado al primer switch...).
     */
    private String[][] list_ports_switches;

    /**
     * Constructor por defecto.
     */
    public GUI_Main() {
        sw_stats = new SwitchStats();
        num_switches = 0;
        list_switches = new String[10];
        num_ports_switches = new String[10];
        name_ports_switches = new String[10][10];
        list_ports_switches = new String[10][10];

        initComponents();

        this.setTitle("OpenPoll App");
        this.setLocationRelativeTo(null);

        File file = new File("../API_OpenPoll/ETSIT.png");

        //Asociamos la imagen de fondo al GUI:
        ImageIcon image = new ImageIcon(file.toString());
        ImageIcon icon = new ImageIcon(image.getImage().getScaledInstance(mainLabel.getWidth(), mainLabel.getHeight(), Image.SCALE_DEFAULT));
        mainLabel.setIcon(icon);

        //Condición de cierre de la GUI de la aplicación:
        closeProgram();
    }

    /**
     * Método para generar las carpetas o directorios de trabajo para los
     * ficheros de datos métricos y los archivos e imágenes de gráficos RRDtool
     * necesarios para la representación y análisis de métricas monitorizadas
     * desde la aplicación OpenPoll.
     */
    public void generateFolders() {
        int cont = 1;

        //Directorio con imágenes rrdtool:
        File directorioimg = null;
        //Directorio con archivos rrdtool:
        File directoriorrd = null;
        //Directorio con ficheros.txt de datos:
        File directoriodata = null;

        while (cont <= 4) {
            switch (cont) {
                case 1:
                    directorioimg = new File("../API_OpenPoll/rrdtool/traffic_stats/byte_rate/images/");
                    directoriorrd = new File("../API_OpenPoll/rrdtool/traffic_stats/byte_rate/rrd_files/");
                    directoriodata = new File("../API_OpenPoll/rrdtool/traffic_stats/byte_rate/data_info/");
                    break;
                case 2:
                    directorioimg = new File("../API_OpenPoll/rrdtool/traffic_stats/packet_rate/images/");
                    directoriorrd = new File("../API_OpenPoll/rrdtool/traffic_stats/packet_rate/rrd_files/");
                    directoriodata = new File("../API_OpenPoll/rrdtool/traffic_stats/packet_rate/data_info/");
                    break;
                case 3:
                    directorioimg = new File("../API_OpenPoll/rrdtool/computation_stats/cpu_load/images/");
                    directoriorrd = new File("../API_OpenPoll/rrdtool/computation_stats/cpu_load/rrd_files/");
                    directoriodata = new File("../API_OpenPoll/rrdtool/computation_stats/cpu_load/data_info/");
                    break;
                case 4:
                    directorioimg = new File("../API_OpenPoll/rrdtool/computation_stats/ram_usage/images/");
                    directoriorrd = new File("../API_OpenPoll/rrdtool/computation_stats/ram_usage/rrd_files/");
                    directoriodata = new File("../API_OpenPoll/rrdtool/computation_stats/ram_usage/data_info/");
                    break;
            }

            if (!directorioimg.exists() || !directoriorrd.exists() || !directoriodata.exists()) {
                if (!directorioimg.exists()) {
                    directorioimg.mkdir();
                }
                if (!directoriorrd.exists()) {
                    directoriorrd.mkdir();
                }
                if (!directoriodata.exists()) {
                    directoriodata.mkdir();
                }
            } else {
                if (directorioimg.isDirectory()) {
                    File[] ficherosimg = directorioimg.listFiles();
                    for (int i = 0; i < ficherosimg.length; i++) {
                        ficherosimg[i].delete();
                    }
                }

                if (directoriorrd.isDirectory()) {
                    File[] ficherosrrd = directoriorrd.listFiles();
                    for (int j = 0; j < ficherosrrd.length; j++) {
                        ficherosrrd[j].delete();
                    }
                }

                if (directoriodata.isDirectory()) {
                    File[] ficherosdata = directoriodata.listFiles();
                    for (int k = 0; k < ficherosdata.length; k++) {
                        ficherosdata[k].delete();
                    }
                }
            }
            cont++;
        }
    }

    /**
     * Método encargado de cerrar el programa en caso de pulsar la 'X' de cierre
     * de la aplicación Java. El método estará a la escucha de si el usuario
     * acciona el cierre de la aplicación, gracias al método propio de los
     * JFrame (addWindowListener()). Una vez se haya pulsado la 'X', se mostrará
     * una ventana de aviso para que el usuario confirme si efectivamente desea
     * salir del programa. Si pulsa que sí, se cerrará la aplicación.
     */
    public void closeProgram() {
        try {
            this.addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent evt) {
                    //int n = JOptionPane.showConfirmDialog(null, "¿Desea salir del programa?", "¡AVISO!", JOptionPane.YES_NO_OPTION);
                    int n = JOptionPane.showConfirmDialog(null, "Do you want to exit the program?", "NOTICE!", JOptionPane.YES_NO_OPTION);
                    if (n == JOptionPane.YES_OPTION) {
                        System.exit(0);
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        etIPHost = new javax.swing.JLabel();
        ctIPHost = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        ctCport = new javax.swing.JTextField();
        btTopology = new javax.swing.JButton();
        etTitulo = new javax.swing.JLabel();
        spTime = new javax.swing.JSpinner();
        etTime = new javax.swing.JLabel();
        mainLabel = new javax.swing.JLabel();
        mbMenu = new javax.swing.JMenuBar();
        mbFile = new javax.swing.JMenu();
        miExit = new javax.swing.JMenuItem();
        mbHelp = new javax.swing.JMenu();
        miAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        etIPHost.setBackground(new java.awt.Color(255, 255, 255));
        etIPHost.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        etIPHost.setText("Controller IP Address: ");
        etIPHost.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        etIPHost.setOpaque(true);
        getContentPane().add(etIPHost, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 80, -1, -1));

        ctIPHost.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ctIPHostActionPerformed(evt);
            }
        });
        getContentPane().add(ctIPHost, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 80, 150, -1));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        jLabel1.setText("Controller port: ");
        jLabel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 130, -1, -1));

        ctCport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ctCportActionPerformed(evt);
            }
        });
        getContentPane().add(ctCport, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 130, 130, -1));

        btTopology.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btTopology.setForeground(new java.awt.Color(0, 153, 204));
        btTopology.setText("Detect topology");
        btTopology.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTopologyActionPerformed(evt);
            }
        });
        getContentPane().add(btTopology, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 220, -1, -1));

        etTitulo.setBackground(new java.awt.Color(255, 255, 255));
        etTitulo.setFont(new java.awt.Font("Garamond", 1, 18)); // NOI18N
        etTitulo.setForeground(new java.awt.Color(0, 153, 204));
        etTitulo.setText(" OpenPoll Tool ");
        etTitulo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 153, 204), new java.awt.Color(0, 153, 204), null, null));
        etTitulo.setOpaque(true);
        getContentPane().add(etTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, 33));

        spTime.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        getContentPane().add(spTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 180, 46, -1));

        etTime.setBackground(new java.awt.Color(255, 255, 255));
        etTime.setFont(new java.awt.Font("Dialog", 1, 14)); // NOI18N
        etTime.setText("Polling time (seconds): ");
        etTime.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        etTime.setOpaque(true);
        getContentPane().add(etTime, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 180, -1, -1));
        getContentPane().add(mainLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 580, 270));

        mbMenu.setBackground(java.awt.Color.gray);

        mbFile.setText("File");

        miExit.setText("Exit");
        miExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miExitActionPerformed(evt);
            }
        });
        mbFile.add(miExit);

        mbMenu.add(mbFile);

        mbHelp.setText("Help");

        miAbout.setText("About");
        miAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAboutActionPerformed(evt);
            }
        });
        mbHelp.add(miAbout);

        mbMenu.add(mbHelp);

        setJMenuBar(mbMenu);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Método perteneciente al cuadro de texto para introducir la dirección IP
     * asociada al equipo donde se encuentra el Controlador de nuestra topogía
     * SDN. A esa dirección se realizarán las peticiones HTTP de la API REST
     * para recoger información y monitorizar el tráfico de la red.
     */
    private void ctIPHostActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ctIPHostActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ctIPHostActionPerformed

    /**
     * Método perteneciente al cuadro de texto para introducir el puerto local
     * para realizar las solicitudes HTTP al Controlador de nuestra topogía SDN
     * mediante la API REST y así recoger información y monitorizar el tráfico
     * de la red.
     *
     * @param evt
     */
    private void ctCportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ctCportActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ctCportActionPerformed

    /**
     * Método para determinar la acción realizada por el botón "Detect Topology"
     * del GUI. Este botón se encargará de determinar la topología del plano de
     * datos SDN en base al número de switches OVS y número de puertos asociados
     * a cada switch que contiene la red para luego monitorizar información de
     * tráfico en la red. También determinará aquellos nodos de gestión de la
     * infraestructura OpenStack para luego monitorizar su carga computacional.
     *
     * En primer lugar, al activar el botón, se comprobará que la dirección IP y
     * puertos, asociados al controlador para realizar las peticiones HTTP
     * mediante la API REST, son correctos y efectivamente podemos realizar las
     * peticiones HTTP al controlador para hallar los switches y puertos de la
     * topología. Para ello, se realizará una prueba de solicitud a través de la
     * API REST, llamando al método requestProve().
     *
     * Si la IP y puerto son incorrectos, se mostrará una ventana de error
     * indicando al usuario que los introduzca correctamente. En caso de que
     * falte por introducir uno de los 2 campos, se mostrará otra ventana de
     * error.
     *
     * Si la prueba de solicitud es correcta y por tanto la IP y puerto de
     * solicitud HTTP, se realizarán las peticiones pertinentes para obtener los
     * switches y puertos asociados de la topología. Las peticiones serán
     * realizadas a través del método discoverTopology() de la clase
     * SwitchStats.
     *
     * Una vez determinada la topología, haremos visible la ventana de la clase
     * GUI_Topology a partir de la cuál podremos proceder a monitorizar
     * información de la infraestructura de red OpenStack gestionada por
     * OpenDayLight.
     *
     *
     * @param evt
     */
    private void btTopologyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTopologyActionPerformed

        //Generamos los directorios necesarios del programa:
        generateFolders();

        String ipaddress = ctIPHost.getText();

        String port = ctCport.getText();

        int time = Integer.parseInt(spTime.getValue().toString());

        Ficheros f = new Ficheros();

        String fichero_ips = "../API_OpenPoll/hosts_ip";
        if (!ipaddress.isEmpty() && !port.isEmpty()) {

            boolean solicitud = true;
            try {
                solicitud = requestProve(ipaddress, port);
            } catch (IOException ex) {
                Logger.getLogger(GUI_Main.class.getName()).log(Level.SEVERE, null, ex);
            }
            if (solicitud == true) {
                this.setCursor(Cursor.WAIT_CURSOR);
                //Descubrir datapath:
                sw_stats.discoverTopology(ipaddress, port);
                num_switches = sw_stats.getNum_switches();
                list_switches = sw_stats.getList_switches();
                num_ports_switches = sw_stats.getNum_ports_switches();
                name_ports_switches = sw_stats.getName_ports_switches();
                list_ports_switches = sw_stats.getList_ports();

                /*
                Obtener direcciones IP de los nodos de la infraestructura OpenStack desde el fichero de texto "ip_hosts" del directorio
                principal del programa para la monitorización de cómputo.
                 */
                ArrayList<String> ip_hosts = new ArrayList<String>();
                ip_hosts = f.leerFicheroIPHosts(fichero_ips);

                //Instanciación de la clase GUI_Topology
                GUI_Topology gt = new GUI_Topology(ipaddress, port, num_switches, list_switches, num_ports_switches, name_ports_switches, list_ports_switches, time, ip_hosts);
                gt.setVisible(true);

                this.setCursor(Cursor.DEFAULT_CURSOR);
            } else {
                //Si se han introducido una dirección IP y un puerto incorrectos para las solicitudes HTTP de la API REST al controlador SDN, mostraremos un mensaje de error.
                //JOptionPane.showMessageDialog(null, "Introduzca dirección IP y puerto correctos.", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                JOptionPane.showMessageDialog(null, "Enter a correct IP address and port.", "ERROR!", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            //Si no se ha introducido la dirección IP y el puerto para las solicitudes HTTP de la API REST al controlador SDN, mostraremos un mensaje de error.
            //JOptionPane.showMessageDialog(null, "Introduzca dirección IP y puerto.", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
            JOptionPane.showMessageDialog(null, "Enter an IP address and a port.", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btTopologyActionPerformed

    /**
     * Método llamado al pulsar el botón "Detect Topology" para comprobar si la
     * IP y Puerto con los que realizar las solicitudes HTTP al controlador
     * mediante la API REST son correctos. Se realizará una prueba de solicitud
     * HTTP y mediante un buffer comprobaremos si la respuesta obtenida es
     * correcta o es una notificación de error. En caso de error, la solicitud
     * no será correcta por lo que IP o/y puerto serán incorrectos. El método
     * recibe por parámetros la IP y puertos a comprobar y devuelve un booleano
     * para notificar si son o no correctos.
     *
     * @param ipaddress
     * @param port
     * @return
     * @throws IOException
     */
    public boolean requestProve(String ipaddress, String port) throws IOException {
        boolean solicitud = true;
        boolean alcanzable = false;
        StringBuilder sb = new StringBuilder();
        try {
            try {
                InetAddress address = InetAddress.getByName(ipaddress);
                alcanzable = address.isReachable(1000);
            } catch (UnknownHostException ex) {
                System.err.println(ex);
            }

            if (alcanzable == true) {
                String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/network-topology:network-topology"};
                Process process1 = Runtime.getRuntime().exec(request);
                InputStream input1 = process1.getInputStream();
                BufferedInputStream buffer1 = new BufferedInputStream(input1);

                int i = 0;
                boolean iniciojson = false;
                while ((i = buffer1.read()) != -1) {
                    sb.append((char) i);
                }

                buffer1.close();
                input1.close();

                if (sb.length() == 0) {
                    InputStream input2 = process1.getErrorStream();
                    BufferedInputStream buffer2 = new BufferedInputStream(input2);
                    i = 0;
                    sb = new StringBuilder();
                    while ((i = buffer2.read()) != -1) {
                        sb.append((char) i);
                    }
                    buffer2.close();
                    input2.close();
                    solicitud = false;
                }

            } else {
                //JOptionPane.showMessageDialog(null, "IP no encontrada.", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                JOptionPane.showMessageDialog(null, "IP not found.", "ERROR!", JOptionPane.WARNING_MESSAGE);
                solicitud = false;
            }

        } catch (Exception e) {
            System.err.println(e);
        }
        return solicitud;
    }

    /**
     * Método para determinar la acción realizada por el item Exit(jMenuItem)
     * del menú File perteneciente a la barra de herramientas (JMenuBar)
     * asociada a la interfaz. La opción Exit se encargará de avisar al usuario,
     * a través de una ventana de confirmación, de si efectivamente desea salir
     * o no del programa, en caso de que el usario la seleccione previamente.
     * (Misma acción que el método closeProgram()).
     *
     * @param evt
     */
    private void miExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miExitActionPerformed
        //int n = JOptionPane.showConfirmDialog(null, "¿Desea salir del programa?", "¡AVISO!", JOptionPane.YES_NO_OPTION);
        int n = JOptionPane.showConfirmDialog(null, "Do you want to exit the program?", "NOTICE!", JOptionPane.YES_NO_OPTION);
        if (n == JOptionPane.YES_OPTION) {
            System.exit(0);
        }

    }//GEN-LAST:event_miExitActionPerformed

    /**
     * Método para determinar la acción realizada por el item About(jMenuItem)
     * del menú Help perteneciente a la barra de herramientas (JMenuBar)
     * asociada a la interfaz. En caso de que el usuario seleccione la opción
     * About, el programa mostrará una ventana informativa con el nombre de la
     * aplicación así como un email de contacto.
     *
     * @param evt
     */
    private void miAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miAboutActionPerformed
        JOptionPane.showMessageDialog(null, "OpenPoll: API to poll metrics information of SDN infrastructures in OpenStack scenarios. \n\n" + "Author: Daniel González Sánchez\n" + "e-mail: daniel.gonzalez.sanchez@alumnos.upm.es", "ABOUT", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_miAboutActionPerformed

    /**
     * Main del GUI.
     *
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GUI_Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GUI_Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GUI_Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GUI_Main.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GUI_Main().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btTopology;
    private javax.swing.JTextField ctCport;
    private javax.swing.JTextField ctIPHost;
    private javax.swing.JLabel etIPHost;
    private javax.swing.JLabel etTime;
    private javax.swing.JLabel etTitulo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel mainLabel;
    private javax.swing.JMenu mbFile;
    private javax.swing.JMenu mbHelp;
    private javax.swing.JMenuBar mbMenu;
    private javax.swing.JMenuItem miAbout;
    private javax.swing.JMenuItem miExit;
    private javax.swing.JSpinner spTime;
    // End of variables declaration//GEN-END:variables
}
