package api_openpoll;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Esta clase se encarga de realizar la monitorización de la red basada en la
 * métrica Packet Rate de la categoría Traffic Statistics.
 *
 * Esta métrica permite extraer el rango de paquetes transmitidos y recibidos
 * por cada puerto de los Open vSwitch del plano de datos SDN. Se trata de una
 * métrica sobre el throughput o tasa de tráfico cursada en los enlaces de los
 * switches datapath, interpretada como medida de calidad de servicio de la red.
 *
 * Para ello, abrirá un hilo de ejecución y se encargará de realizar una
 * solicitud HTTP al controlador OpenDayLight de la red SDN a través de la API
 * REST, solicitando los datos necesarios para obtener el rango de paquetes
 * transmitidos y recibidos de el puerto y el switch OVS indicados en cada
 * instante de tiempo.
 *
 * Las métricas o estadísticas calculadas sobre rango de paquetes recibidos
 * serán almacenadas en archivos .rrd de tipo RRDTOOL para luego ser
 * representadas en gráficas que serán visualizadas a partir de la clase
 * GUI_Graph. Cierta información estadística también será almacenada en ficheros
 * de texto para su posterior uso y representación desde GUI_Graph.
 *
 * @author Daniel González Sánchez
 */
public class PacketRate {

    /**
     * Atributo para almacenar los paquetes recibidos a través del puerto del
     * switch.
     */
    private long receivedPackets;

    /**
     * Atributo para almacenar los paquetes transmitidos por el puerto del
     * switch.
     */
    private long transmittedPackets;

    /**
     * Atributo para almacenar los paquetes recibidos borrados por el puerto del
     * switch.
     */
    private long rx_dropped;

    /**
     * Atributo para almacenar los paquetes transmitidos borrados por el puerto
     * del switch.
     */
    private long tx_dropped;

    /**
     * Atributo para almacenar los errores recibidos por el puerto del switch.
     */
    private long rx_errors;

    /**
     * Atributo para almacenar los errores transmitidos por el puerto del
     * switch.
     */
    private long tx_errors;

    /**
     * Atributo para almacenar el número de errores de CRC.
     */
    private long crc_errors;

    /**
     * Atributo para almacenar el número de colisiones.
     */
    private long collisions;

    /**
     * Atributo para almacenar el número de tramas recibidas.
     */
    private long rx_frame_errors;

    /**
     * Atributo para almacenar el número de errores de ejecución recibidos.
     */
    private long rx_overrun_errors;

    /**
     * Atributo para tomar el rango de paquetes recibidos por segundo.
     */
    private double rx_pack_rate;

    /**
     * Atributo para tomar el rango de paquetes transmitidos por segundo.
     */
    private double tx_pack_rate;

    /**
     * Atributo para almacenar la duración o tiempo de la muestra en segundos.
     */
    private int sample_duration;

    /**
     * Atributo para almacenar el campo duration(segundos) de los flujos
     * monitorizados.
     */
    private long duration_s;

    /**
     * Atributo para almacenar el campo duration(nanosegundos) de los flujos
     * monitorizados.
     */
    private long duration_ns;

    /**
     * Atributo para almacenar la IP asociada al controlador para establecer la
     * conexión a la API REST del controlador ODL y poder realizar las
     * peticiones HTTP.
     */
    private String ipaddress;

    /**
     * Atributo para almacenar el puerto asociado al controlador para establecer
     * la conexión a la API REST del controlador ODL y poder realizar las
     * peticiones HTTP.
     */
    private String port;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo entero donde almacenar el identificador del switch a
     * monitorizar.
     */
    private String id_sw;

    /**
     * Atributo entero donde almacenar el identificador del puerto del switch a
     * monitorizar.
     */
    private String id_port;

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Atributo entero para determinar el número de muestra de monitorización.
     * Variable para remarcar cúando se realiza la primera muestra de
     * monitorización. Esta primera muestra no será correcta debido a que no
     * conoceremos la que sería la muestra anterior con las métricas y por tanto
     * los cálculos de uso de puerto no serían correctos. Por ello, RRDTOOL
     * obviará la primera muestra y no la recogerá en su base de datos ni la
     * representará gráficamente. Esta variable será recibida en el Shell Script
     * de creación y actualización de la base de datos RRD, de tal forma que
     * para la primera muestra recibirá un 1 y no actualizará la base de datos y
     * para muestras posteriores recibirá un 0 indicando que ya no es la muestra
     * inicial y por tanto se podrá actualizar RRD y representarse es su
     * gráfica.
     */
    private int muestra_inicial;

    /**
     * Array List donde iremos almacenando los datos y métricas monitorizadas.
     */
    private ArrayList<String> info;

    /**
     * Constructor por defecto.
     */
    public PacketRate() {
        receivedPackets = 0;
        transmittedPackets = 0;
        sample_duration = 0;
        rx_pack_rate = 0;
        tx_pack_rate = 0;
        cerrar = false;
    }

    /**
     * Constructor parametrizado.
     *
     * @param ipaddress
     * @param port
     * @param time
     * @param id_sw
     * @param id_port
     * @param muestra_inicial
     */
    public PacketRate(String ipaddress, String port, int time, String id_sw, String id_port, int muestra_inicial) {
        this.ipaddress = ipaddress;
        this.port = port;
        this.time = time;
        this.id_sw = id_sw;
        this.id_port = id_port;
        this.muestra_inicial = muestra_inicial;
    }

    /**
     * Método con la lógica de las peticiones HTTP para extraer las métricas de
     * rango de paquetes monitorizadas por cada uno de los puertos de los switch
     * OVS. Mediante la API REST de OpenDayLight se realizará la petición HTTP
     * correspondiente al controlador SDN y se extraerán los datos necesarios
     * para calcular la métrica en cuestión.
     *
     * Este método será llamado desde la clase TrafficStats al seleccionar la
     * opción Packet Rate y el botón Traffic Graph de la GUI_Topology. Se
     * encargará de monitorizar el rango de paquetes recibidos y transmitidos
     * por segundo por cada switch OVS en nuestra red SDN a través de cada uno
     * de sus puertos.
     *
     * Esta clase recibe por parámetro la dirección IP y el puerto del
     * controlador necesarios para realizar las peticiones HTTP, así como el id
     * del switch y el id del puerto asociado para poder realizar la petición
     * HTTP por la API REST.
     *
     * La petición HTTP a través de la API REST se realiza lanzando un comando
     * Linux desde Java con el método Runtime.getRuntime().exec(). La petición
     * en ese caso es la siguiente: curl -u "admin:admin" -H "Accept:
     * application/json" -H "Content-type: application/json" -X GET
     * "http://{ipaddress}:{port}/restconf/
     * operational/opendaylight-inventory:nodes/node/openflow:{id_sw}/node-connector/
     * openflow:{id_sw}:{id_port}/opendaylight-port-statistics:query-capable-node-connector-statistics"
     * ,(donde id_sw e id_port serán los identificadores del switch OVS y puerto
     * asociado a monitorizar).
     *
     * Desde un buffer recogeremos la información proporcionada al realizar la
     * petición. Los datos de la respuesta son generados como objetos tipo JSON
     * propio de JavaScript. A partir del método .get() de los objetos JSON,
     * podremos filtrar la información necesaria para obtener los paquetes
     * recibidos y transmitidos en cada instante de tiempo así como la duración
     * o timestap de la muestra. A partir de estos parámetros podremos obtener
     * el rango de paquetes recibidos y transmitidos por cada puerto en un
     * intervalo de tiempo determinado. Este tiempo equivaldrá al tiempo de
     * sondeo que el usuario eligió en el GUI_Main inicial. Es decir, el tiempo
     * de cada muestra para hallar los rangos de paquetes será igual al tiempo
     * de muestreo o polling time.
     *
     * Una vez monitorizados los datos necesarios para obtener la métrica, ya
     * podremos representar la gráfica. Para ello, deberemos generar la gráfica
     * RRDTOOL con los datos obtenidos. Lo primero será crear la base de datos
     * circular propia de RRDTOOl (Round Robin Database) siempre que no exista.
     * Una vez generada, se irá actualizando con los valores de las métricas que
     * se vayan obteniendo por cada muestra (comentar que el paso o toma de
     * datos en la Base de Datos está definida en un mínimo de 1 segundo). Por
     * último, se generará la gráfica según los valores registrados en la base
     * de datos a una escala e intervalo de tiempo determinada (se irán
     * mostrando los datos registrados durante los últimos 10 minutos). Las
     * funciones de creación, actualización de la base de datos RRDTOOL y la
     * generación de la gráfica están desarrolladas en 2 shell scripts
     * diferentes que se encuentra en el la carpeta del proyecto API_OpenPoll,
     * en el subdirectorio ../rddtool/traffic_stats/packet_rate/. Además, en ese
     * directorio se generarán la imagen de la gráfica RRDTOOL en formato .png y
     * el archivo de la base de datos circular .rrd. Estos scripts serán
     * lanzados desde java con el método Runtime.getRuntime().exec().
     *
     * El contenido monitorizado será almacenado en un ArrayList "info" el cúal
     * será almacenado en un fichero del directorio
     * ../rrdtool/traffic_stats/packet_rate/data_info/. Este directorio y la
     * gráfica RRDTOOL serán accedidos posteriormente desde la clase GUI_Graph
     * para así poder obtener información de la estadísticas y gráficas de
     * monitorización en tiempo real.
     *
     * Decir que este método recibe por parámetro una variable vector donde ir
     * almacenando donde ir almacenando contadores relacionados con los paquetes
     * transmitidos y recibidos de cada puerto de un OVSwitch por cada muestra.
     *
     * @param packet_rate
     * @return
     */
    public long[] monitoring(long packet_rate[]) {

        //Array List donde iremos almacenando los datos y métricas monitorizadas.
        ArrayList<String> info = new ArrayList<String>();

        //Directorio del proyecto:
        File dir = new File("../API_OpenPoll");

        //Instanciación de objeto de la clase Ficheros:
        Ficheros f = new Ficheros();

        /*
        Variable donde ir almacenando los paquetes transmitidos por cada muestra.
         */
        long packets_t = 0;

        /*
        Variable donde ir almacenando los paquetes recibidos por cada muestra.
         */
        long packets_r = 0;

        /*
        Variable donde ir almacenando los paquetes trasnmitidos perdidos por cada muestra.
         */
        long dropped_t = 0;

        /*
        Variable donde ir almacenando los paquetes recibidos perdidos por cada muestra.
         */
        long dropped_r = 0;

        /*
        Variabla donde ir almacenando los errores transmitidos por cada muestra.
         */
        long errors_t = 0;

        /*
        Variable donde ir almacenando los errores recibidos por cada muestra.
         */
        long errors_r = 0;

        /*
        Variable donde ir almacenando los errores de crc por cada muestra.
         */
        long crc_err = 0;

        /*
        Variable donde ir almacenando las colisiones producidas por cada muestra.
         */
        long coll = 0;

        /*
        Variable donde ir almacenando los errores de tramas por cada muestra.
         */
        long frame_err = 0;

        /*
        Variable donde ir almacenando los errores de ejecución por cada muestra.
         */
        long overrun_err = 0;


        /*
        Variable donde almacenar lospaquetes transmitidos de la anterior muestra y
        así calcular junto con los de la muestra actual (packets_t) los paquetes transmitidos
        en el intervalo de tiempo entre muestra y muestra.
         */
        long packets_t_previous = 0;

        /*
        Variable donde almacenar los paquetes recibidos de la anterior muestra y
        así calcular junto con los de la muestra actual (packets_r) los paquetes recibidos
        en el intervalo de tiempo entre muestra y muestra.
         */
        long packets_r_previous = 0;

        /*
        Variable donde almacenar los paquetes transmitidos perdidos de la anterior muestra y
        así calcular junto con los de la muestra actual (dropped_t) los paquetes transmitidos 
        perdidos en el intervalo de tiempo entre muestra y muestra.
         */
        long dropped_t_previous = 0;

        /*
        Variable donde almacenar los paquetes recibidos perdidos de la anterior muestra y
        así calcular junto con los de la muestra actual (dropped_r) los paquetes recibidos 
        perdidos en el intervalo de tiempo entre muestra y muestra.
         */
        long dropped_r_previous = 0;

        /*
        Variable donde almacenar los errores transmitidos de la anterior muestra y
        así calcular junto con los de la muestra actual (errors_t) los errores transmitidos 
        en el intervalo de tiempo entre muestra y muestra.
         */
        long errors_t_previous = 0;

        /*
        Variable donde almacenar los errores recibidos de la anterior muestra y
        así calcular junto con los de la muestra actual (errors_r) los errores recibidos 
        en el intervalo de tiempo entre muestra y muestra.
         */
        long errors_r_previous = 0;

        /*
        Variable donde almacenar los errores de CRC producidos de la anterior muestra y así
        calcular junto con los de la muestra actual (crc_err) los errores de CRC en 
        el intervalo de tiempo entre muestra y muestra.
         */
        long crc_err_previous = 0;

        /*
        Variable donde almacenar las colisiones producidas de la anterior muestra y así 
        calcular junto con los de la muestra actual (coll) las colisiones en el intervalo
        de tiempo entre muestra y muestra.
         */
        long coll_previous = 0;

        /*
        Variable donde almacenar los errores de trama producidos de la anterior muestra y así 
        calcular junto con los de la muestra actual (frame_err) los errores de trama en el intervalo
        de tiempo entre muestra y muestra.
         */
        long frame_err_previous = 0;

        /*
        Variable donde almacenar los errores de ejecución producidos de la anterior muestra y así 
        calcular junto con los de la muestra actual (overrun_err) los errores de ejecución en el intervalo
        de tiempo entre muestra y muestra.
         */
        long overrun_err_previous = 0;

        packets_t = packet_rate[0];
        packets_r = packet_rate[1];
        dropped_t = packet_rate[2];
        dropped_r = packet_rate[3];
        errors_t = packet_rate[4];
        errors_r = packet_rate[5];
        coll = packet_rate[6];
        crc_err = packet_rate[7];
        frame_err = packet_rate[8];
        overrun_err = packet_rate[9];

        try {
            //Por cada muestra vaciaremos el contenido del array list para obtener nuevos datos y métricas monitorizadas:
            info.clear();

            //Realizamos la solicitud HTTP al controlador por la API REST para obtener las métricas:
            String[] query = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes/node/openflow:" + id_sw + "/node-connector/openflow:" + id_sw + ":" + id_port + "/opendaylight-port-statistics:flow-capable-node-connector-statistics"};

            Process process1 = Runtime.getRuntime().exec(query);
            InputStream input1 = process1.getInputStream();
            BufferedInputStream buffer1 = new BufferedInputStream(input1);
            StringBuilder sb = new StringBuilder();
            int i;
            JSONObject jso = new JSONObject();

            boolean iniciojson = false;
            int cont = 0;

            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer1.read()) != -1) {

                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }

            iniciojson = false;

            buffer1.close();
            input1.close();

            packets_r_previous = packets_r;
            packets_t_previous = packets_t;
            dropped_t_previous = dropped_t;
            dropped_r_previous = dropped_r;
            errors_t_previous = errors_t;
            errors_r_previous = errors_r;
            coll_previous = coll;
            crc_err_previous = crc_err;
            frame_err_previous = frame_err;
            overrun_err_previous = overrun_err;

            packets_t = 0;
            packets_r = 0;
            dropped_t = 0;
            dropped_r = 0;
            errors_t = 0;
            errors_r = 0;

            coll = 0;
            crc_err = 0;
            frame_err = 0;
            overrun_err = 0;

            try {
                /*
                    Recogemos la muestra en un JSONObject y hallaremos los campos necesarios 
                    con el método .get() para calcular las métricas:
                 */
                jso = new JSONObject(sb.toString());

                JSONObject packStats = new JSONObject(jso.get("packets").toString());

                //Hallamos los paquetes totales recibidos y lo almacenamos en el array list:
                packets_r = (long) ((Number) packStats.get("received")).longValue();
                info.add("Total packets received: " + Long.toString(packets_r));

                //Hallamos los paquetes totales transmitidos y lo almacenamos en el array list:
                packets_t = (long) ((Number) packStats.get("transmitted")).longValue();
                info.add("Total packets transmitted: " + Long.toString(packets_t));

                //Calculamos los paquetes recibidos durante la muestra y lo almacenamos en el array list:
                receivedPackets = packets_r - packets_r_previous;
                info.add("Current packets received: " + Long.toString(receivedPackets));

                //Calculamos los paquetes transmitidos durante la muestra y lo almacenamos en el array list:
                transmittedPackets = packets_t - packets_t_previous;
                info.add("Current packets transmitted: " + Long.toString(transmittedPackets));

                //Calculamos el intervalo de tiempo de la muestra y lo almacenamos en el array list:
                sample_duration = time;
                info.add("Sample duration: " + Integer.toString(sample_duration));

                JSONObject durationStats = new JSONObject(jso.get("duration").toString());

                duration_s = (long) ((Number) durationStats.get("second")).longValue();
                info.add("Duration (seconds): " + Long.toString(duration_s));

                duration_ns = (long) ((Number) durationStats.get("nanosecond")).longValue();
                info.add("Duration (nanoseconds): " + Long.toString(duration_ns));

                /*
                    Calculamos la métrica de rango de paquetes recibidos durante el intervalo
                    de tiempo estimado y lo almacenamos en el array list:
                 */
                rx_pack_rate = (double) receivedPackets / sample_duration;
                info.add("Received packets rate: " + Double.toString(rx_pack_rate));

                /*
                    Calculamos la métrica de rango de paquetes transmitidos durante el intervalo
                    de tiempo estimado y lo almacenamos en el array list:
                 */
                tx_pack_rate = (double) transmittedPackets / sample_duration;
                info.add("Transmitted packets rate: " + Double.toString(tx_pack_rate));

                String port_name = requestPortName();

                if (!port_name.startsWith("tun")) {

                    //Hallamos los paquetes totales recibidos perdidos y los almacenamos en el array list:
                    dropped_r = (long) ((Number) jso.get("receive-drops")).longValue();
                    info.add(("Total packet received dropped: " + Long.toString(dropped_r)));

                    //Hallamos los paquetes totales transmitidos perdidos y los almacenamos en el array list:
                    dropped_t = (long) ((Number) jso.get("transmit-drops")).longValue();
                    info.add(("Total packet transmitted dropped: " + Long.toString(dropped_t)));

                    //Hallamos los errores totales recibidos y los almacenamos en el array list:
                    errors_r = (long) ((Number) jso.get("receive-errors")).longValue();
                    info.add(("Total errors received: " + Long.toString(errors_r)));

                    //Hallamos los errores totales transmitidos perdidos y los almacenamos en el array list:
                    errors_t = (long) ((Number) jso.get("transmit-errors")).longValue();
                    info.add(("Total errors transmitted: " + Long.toString(errors_t)));

                    //Hallamos los errores totales de CRC y los almacenamos en el array list.
                    crc_err = (long) ((Number) jso.get("receive-crc-error")).longValue();
                    info.add(("Total CRC errors: ") + Long.toString(crc_err));

                    //Hallamos las colisiones totales y los almacenamos en el array list.
                    coll = (long) ((Number) jso.get("collision-count")).longValue();
                    info.add(("Total collisions: ") + Long.toString(coll));

                    //Hallamos los errores totales de tramas y los almacenamos en el array list.
                    frame_err = (long) ((Number) jso.get("receive-frame-error")).longValue();
                    info.add(("Total frame errors: ") + Long.toString(frame_err));

                    //Hallamos los errores totales de ejecución y los almacenamos en el array list.
                    overrun_err = (long) ((Number) jso.get("receive-over-run-error")).longValue();
                    info.add(("Total over run errors: ") + Long.toString(overrun_err));

                    //Calculamos los paquetes recibidos perdidos durante la muestra y lo almacenamos en el array list:
                    rx_dropped = dropped_r - dropped_r_previous;
                    info.add("Current packets dropped received: " + Long.toString(rx_dropped));

                    //Calculamos los paquetes transmitidos perdidos durante la muestra y los almacenamos en el array list:
                    tx_dropped = dropped_t - dropped_t_previous;
                    info.add("Current packets dropped transmitted: " + Long.toString(tx_dropped));

                    //Calculamos los errores recibidos durante la muestra y los almacenamos en el array list:
                    rx_errors = dropped_r - dropped_r_previous;
                    info.add("Current errors received: " + Long.toString(rx_errors));

                    //Calculamos los errores transmitidos durante la muestra y los almacenamos en el array list:
                    tx_errors = dropped_t - dropped_t_previous;
                    info.add("Current errors transmitted: " + Long.toString(tx_errors));

                    //Calculamos los errores de CRC durante la muestra y los almacenamos en el array list:
                    crc_errors = crc_err - crc_err_previous;
                    info.add("Current CRC errors: " + Long.toString(crc_errors));

                    //Calculamos las colisiones producidas durante la muestra y las almacenamos en el array list:
                    collisions = coll - coll_previous;
                    info.add("Current collisions: " + Long.toString(collisions));

                    //Calculamos los errores de trama producidos durante la muestra y los almacenamos en el array list:
                    rx_frame_errors = frame_err - frame_err_previous;
                    info.add("Current fram errors: " + Long.toString(rx_frame_errors));

                    //Calculamos los errores de ejecución producidos durante la muestra y las almacenamos en el array list:
                    rx_overrun_errors = overrun_err - overrun_err_previous;
                    info.add("Current over run errors: " + Long.toString(rx_overrun_errors));

                }

                /*
                    Lanzamos el script de creación y actualización de la base de datos RDDTOOL.
                    Recibirá por parámetro las métricas de paquetes transmitidos y recibidos y 
                    la variable muestra_inicial.
                 */
                String[] createDatabase = {"/bin/sh", "-c", "cd " + dir.getPath() + "/rrdtool/traffic_stats/packet_rate; ./packet_rate_db.sh " + tx_pack_rate + " " + rx_pack_rate + " " + muestra_inicial + " " + "packet_rate_db_" + id_sw + "_" + id_port + ".rrd"};
                Process process2 = Runtime.getRuntime().exec(createDatabase);
                InputStream input2 = process2.getInputStream();
                BufferedInputStream buffer2 = new BufferedInputStream(input2);
                int j;

                /*while ((j = buffer2.read()) != -1) {
                        //System.out.print((char) j);
                    }*/
                input2.close();
                buffer2.close();

                /*
                    Lanzamos el script para generar la gráfica RDDTOOL con los datos de la base de datos RRDTOOL
                    actualizados.
                 */
                String[] grafico = {"/bin/sh", "-c", "cd " + dir.toString() + "/rrdtool/traffic_stats/packet_rate; ./packet_rate_graph.sh end-600s now " + "packet_rate_db_" + id_sw + "_" + id_port + ".rrd" + " " + "packet_rate_" + id_sw + "_" + id_port + ".png"};
                Process process3 = Runtime.getRuntime().exec(grafico);
                InputStream input3 = process3.getInputStream();
                BufferedInputStream buffer3 = new BufferedInputStream(input3);
                int k;

                /*while ((k = buffer3.read()) != -1) {
                        //System.out.print((char) k);
                    }*/
                input3.close();
                buffer3.close();

            } catch (JSONException e) {
                e.printStackTrace();
            }

            StringBuilder data_info = new StringBuilder();
            for (int x = 0; x < info.size(); x++) {
                data_info.append(info.get(x));
                data_info.append(System.getProperty("line.separator"));
            }

            //Escribimos en el fichero la información estadística de monitorización recogida en el arraylist:
            String fichero = "../API_OpenPoll/rrdtool/traffic_stats/packet_rate/data_info/packet_rate_" + id_sw + "_" + id_port + ".txt";
            f.escribirFichero(fichero, data_info.toString());

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }

        packet_rate[0] = packets_t;
        packet_rate[1] = packets_r;
        packet_rate[2] = dropped_t;
        packet_rate[3] = dropped_r;
        packet_rate[4] = errors_t;
        packet_rate[5] = errors_r;
        packet_rate[6] = crc_err;
        packet_rate[7] = coll;
        packet_rate[8] = frame_err;
        packet_rate[9] = overrun_err;

        return packet_rate;
    }

    /**
     * Método para obtener el nombre de puerto asociado a un puerto OVSwitch. Se
     * realiza una petición HTTP mediante la API REST para obtener dicha
     * información.
     *
     * @return
     * @throws IOException
     */
    public String requestPortName() throws IOException {
        //Realizamos la solicitud HTTP al controlador por la API REST:
        String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes/node/openflow:" + id_sw + "/node-connector/openflow:" + id_sw + ":" + id_port};

        Process process = Runtime.getRuntime().exec(request);
        InputStream input = process.getInputStream();
        BufferedInputStream buffer = new BufferedInputStream(input);
        int i;
        JSONObject jso = new JSONObject();
        StringBuilder sb = new StringBuilder();
        boolean iniciojson = false;
        int cont = 0;
        String port_name = new String();

        /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
         */
        while ((i = buffer.read()) != -1) {

            if ((char) i == '{') {
                cont++;
            }
            if (cont == 2) {
                iniciojson = true;
            }
            if (iniciojson == true) {
                sb.append((char) i);
            }
        }
        try {
            jso = new JSONObject(sb.toString());
            port_name = jso.get("flow-node-inventory:name").toString();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return port_name;
    }
}
