package api_openpoll;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ItemEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import java.net.URL;
import java.util.Vector;
import javafx.scene.control.ScrollBar;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import jdk.nashorn.internal.runtime.options.Options;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Esta clase se trata de la GUI para la gestión y monitorización de información
 * de la infraestructura de red OpenStack-SDN. Una vez detectada la topología de
 * red (switches OVS del plano de datos y nodos de gestión de la
 * infraestructura), el usuario podrá elegir el switch OVS y puerto del mismo
 * sobre el que se está monitorizando información de tráfico de la red
 * dependiendo de diferentes métricas o estadísticas por puerto o tabla de
 * flujos del switch. También se podrá elegir un nodo de gestión de la red sobre
 * el cuál estudiar la monitorización de cómputo realizada. Además podrá obtener
 * información descriptiva adicional de la topología de red sobre los switches y
 * puertos seleccionados y los hosts asociados, junto con información sobre los
 * recursos de redes virtuales instanciadas y las tablas de flujo instaladas
 * desde OpenDayLight en los OVS para gestionar diferentes servicios de red.
 *
 * @author Daniel González Sánchez
 */
public class GUI_Topology extends javax.swing.JFrame {

    /**
     * Atributo para almacenar la IP asociada al controlador para establecer la
     * conexión entre la API REST y el controlador y poder realizar las
     * peticiones HTTP.
     */
    private String ipaddress;

    /**
     * Atributo para almacenar el puerto asociado al controlador para establecer
     * la conexión entre la API REST y el controlador y poder realizar las
     * peticiones HTTP.
     */
    private String port;

    /**
     * Atributo entero donde almacenar el número de switches que contiene
     * nuestra topología de red.
     */
    private int num_sw;

    /**
     * Atributo vector de Strings con la lista de switches existentes (números
     * identificativos de los switches) en la topología de red.
     */
    private String[] list_sw;

    /**
     * Atributo vector de String donde almacenaremos el número de puertos que
     * contiene cada switch de nuestra topología.
     */
    private String[] num_ports_sw;

    /**
     * Atributo mastriz de String donde almacenaremos el nombre de cada puerto
     * de cada uno de los switches de nuestra topología.
     */
    private String[][] name_ports_sw;

    /**
     * Atributo matriz de String donde almacenaremos la lista de números o
     * identificadores de los puertos de cada switch de la topología de red.
     */
    private String[][] list_ports_sw;

    /**
     * Attibuto ArrayList de String para almacenar las direcciones IP de los
     * nodos de despliegue de la infraestructura Cloud.
     */
    private ArrayList<String> ip_hosts;

    /**
     * Atributo objeto de la clase JTextArea.
     */
    private JTextArea jtx;

    /**
     * Atributo objeto de la clase JTable.
     */
    private JTable tabla;

    /**
     * Atributo para recoger el tiempo de muestreo o sondeo (polling time) para
     * la monitorización.
     */
    private int time;

    /**
     * Atributo booleano para detallar que se inició el sondeo de monitorización
     * de la infraestructura de red.
     */
    private boolean start_monitoring = false;

    /**
     * Constructor parametrizado.
     *
     * @param ipaddress
     * @param port
     * @param num_sw
     * @param list_sw
     * @param num_ports_sw
     * @param name_ports_sw
     * @param list_ports
     * @param time
     * @param ip_hosts
     */
    public GUI_Topology(String ipaddress, String port, int num_sw, String[] list_sw, String[] num_ports_sw, String[][] name_ports_sw, String[][] list_ports, int time, ArrayList<String> ip_hosts) {
        this.ipaddress = ipaddress;
        this.port = port;
        this.num_sw = num_sw;
        this.list_sw = list_sw;
        this.num_ports_sw = num_ports_sw;
        this.name_ports_sw = name_ports_sw;
        this.list_ports_sw = list_ports;
        this.time = time;
        this.ip_hosts = ip_hosts;

        initComponents();

        this.setSize(1196, 420);
        this.getContentPane().setBackground(Color.WHITE);
        this.setTitle("OpenPoll App");
        this.setLocationRelativeTo(null);

        //spInfo.setAlignmentX(JScrollPane.TOP_ALIGNMENT);
        //spInfo.setAlignmentY(JScrollPane.TOP_ALIGNMENT);
        //spInfo.getViewport().setViewPosition(new Point(0, 0));
        //Actualizamos los Items del JComboBox de elección del switch (cbSwitches):
        for (int i = 0; i < num_sw; i++) {
            cbSwitches.addItem(list_sw[i]);
        }

        cbSwitches.setSelectedItem(null);

        this.cbPort.setModel(new DefaultComboBoxModel());
        cbPort.setSelectedItem(null);

        for (int j = 0; j < ip_hosts.size(); j++) {
            cbHosts.addItem(ip_hosts.get(j));
        }
        cbHosts.setSelectedItem(null);

        JLabel label = new JLabel();
        File file = new File("../API_OpenPoll/UPM.png");
        ImageIcon image = new ImageIcon(file.toString());
        ImageIcon icon = new ImageIcon(image.getImage().getScaledInstance(spInfo.getWidth() - 70, spInfo.getHeight() - 25, Image.SCALE_AREA_AVERAGING));
        label.setIcon(icon);

        spInfo.getViewport().setBackground(Color.WHITE);
        spInfo.setViewportView(label);

        //Condición de cierre de la GUI:
        cerrarVentana();
    }

    /**
     * Método para realizar las solicitudes periódicas para monitorizar el
     * estado del plano de datos de la red SDN mediante la API REST y el estudio
     * de cómputo de los hosts de gestión de la infraestrucutura a través de
     * SNMP y NRPE.
     *
     * De esta forma podremos proceder a monitorizar tráfico y obtener
     * información de la red en base a los switches y sus puertos y tablas de
     * flujo determinados y a diferentes opciones de estudio de cómputo de la
     * red.
     *
     * Se lanzarán hilos de ejecución por cada switch y host de la red para
     * realizar la monitorización.
     *
     * @param button
     */
    public void solicitudesMonitorizacion(JButton button) {
        start_monitoring = true;

        for (int i = 0; i < num_sw; i++) {
            Solicitudes_API_REST sap = new Solicitudes_API_REST(ipaddress, port, Integer.parseInt(num_ports_sw[i]), list_sw[i], list_ports_sw[i], time, GUI_Topology.this, button);
            sap.start();
        }

        Solicitudes_Computo scomp = new Solicitudes_Computo(time, ip_hosts, GUI_Topology.this, button);
        scomp.start();
    }

    /**
     * Método encargado de cerrar la ventana en caso de pulsar la 'X' de cierre
     * de la aplicación Java. El método estará a la escucha de si el usuario
     * acciona el cierre, gracias al método propio de los JFrame
     * (addWindowListener()). Una vez se haya pulsado la 'X', se mostrará una
     * ventana de aviso para que el usuario confirme si efectivamente desea
     * cerrar esta ventana. Si pulsa que sí, se cerrará la ventana.
     */
    public void cerrarVentana() {
        try {
            this.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
            addWindowListener(new WindowAdapter() {
                @Override
                public void windowClosing(WindowEvent evt) {
                    //int n = JOptionPane.showConfirmDialog(null, "¿Desea cerrar la ventana?", "¡AVISO!", JOptionPane.YES_NO_OPTION);
                    int n = JOptionPane.showConfirmDialog(null, "Do you want to exit the window?", "NOTICE!", JOptionPane.YES_NO_OPTION);
                    if (n == JOptionPane.YES_OPTION) {
                        dispose();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        cbSwitches = new javax.swing.JComboBox<>();
        cbPort = new javax.swing.JComboBox<>();
        btTrafficGraph = new javax.swing.JButton();
        etSwitch = new javax.swing.JLabel();
        etPort = new javax.swing.JLabel();
        pTrafficStats = new javax.swing.JPanel();
        btPckRate = new javax.swing.JRadioButton();
        btByteRate = new javax.swing.JRadioButton();
        spInfo = new javax.swing.JScrollPane();
        btTopoInfo = new javax.swing.JButton();
        spTime = new javax.swing.JSpinner();
        etTime = new javax.swing.JLabel();
        btNetInfo = new javax.swing.JButton();
        btFlowRules = new javax.swing.JButton();
        btStartPolling = new javax.swing.JButton();
        btStopPolling = new javax.swing.JButton();
        etHost = new javax.swing.JLabel();
        cbHosts = new javax.swing.JComboBox<>();
        btHostInfo = new javax.swing.JButton();
        pComputation = new javax.swing.JPanel();
        btCPULoad = new javax.swing.JRadioButton();
        btRAMUsg = new javax.swing.JRadioButton();
        btCompute = new javax.swing.JButton();
        mbMenu = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        miExit = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        miAbout = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);

        cbSwitches.setBackground(new java.awt.Color(255, 255, 255));
        cbSwitches.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        cbSwitches.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbSwitchesItemStateChanged(evt);
            }
        });
        cbSwitches.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbSwitchesActionPerformed(evt);
            }
        });

        cbPort.setBackground(new java.awt.Color(255, 255, 255));
        cbPort.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbPortItemStateChanged(evt);
            }
        });
        cbPort.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbPortActionPerformed(evt);
            }
        });

        btTrafficGraph.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btTrafficGraph.setForeground(new java.awt.Color(0, 153, 204));
        btTrafficGraph.setText("Traffic Graph");
        btTrafficGraph.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTrafficGraphActionPerformed(evt);
            }
        });

        etSwitch.setBackground(new java.awt.Color(255, 255, 255));
        etSwitch.setForeground(new java.awt.Color(0, 153, 204));
        etSwitch.setText("Choose switch id: ");
        etSwitch.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        etSwitch.setOpaque(true);

        etPort.setBackground(new java.awt.Color(255, 255, 255));
        etPort.setForeground(new java.awt.Color(0, 153, 204));
        etPort.setText("Choose switch port: ");
        etPort.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        etPort.setOpaque(true);

        pTrafficStats.setBackground(new java.awt.Color(255, 255, 255));
        pTrafficStats.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(0, 153, 204), new java.awt.Color(0, 153, 204), null, null), "Traffic Statistics", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 0, 12), new java.awt.Color(0, 153, 204))); // NOI18N
        pTrafficStats.setForeground(new java.awt.Color(0, 153, 204));
        pTrafficStats.setPreferredSize(new java.awt.Dimension(175, 108));

        btPckRate.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(btPckRate);
        btPckRate.setText("Packet Rate");
        btPckRate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPckRateActionPerformed(evt);
            }
        });

        btByteRate.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup1.add(btByteRate);
        btByteRate.setText("Byte Rate");

        javax.swing.GroupLayout pTrafficStatsLayout = new javax.swing.GroupLayout(pTrafficStats);
        pTrafficStats.setLayout(pTrafficStatsLayout);
        pTrafficStatsLayout.setHorizontalGroup(
            pTrafficStatsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pTrafficStatsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pTrafficStatsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btPckRate)
                    .addComponent(btByteRate))
                .addContainerGap(41, Short.MAX_VALUE))
        );
        pTrafficStatsLayout.setVerticalGroup(
            pTrafficStatsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pTrafficStatsLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(btPckRate)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btByteRate)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        spInfo.setBackground(new java.awt.Color(255, 255, 255));
        spInfo.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(0, 153, 204), new java.awt.Color(0, 153, 204), null, null));
        spInfo.setToolTipText("");
        spInfo.setAutoscrolls(true);
        spInfo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        spInfo.setOpaque(false);

        btTopoInfo.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btTopoInfo.setForeground(new java.awt.Color(0, 153, 204));
        btTopoInfo.setText("Topology Info");
        btTopoInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btTopoInfoActionPerformed(evt);
            }
        });

        spTime.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        spTime.setBorder(null);

        etTime.setBackground(new java.awt.Color(255, 255, 255));
        etTime.setText("Refresh time (seconds): ");
        etTime.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        etTime.setOpaque(true);

        btNetInfo.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btNetInfo.setForeground(new java.awt.Color(0, 153, 204));
        btNetInfo.setText("Nework Info");
        btNetInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btNetInfoActionPerformed(evt);
            }
        });

        btFlowRules.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btFlowRules.setForeground(new java.awt.Color(0, 153, 204));
        btFlowRules.setText("Flow Rules");
        btFlowRules.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btFlowRulesActionPerformed(evt);
            }
        });

        btStartPolling.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btStartPolling.setForeground(new java.awt.Color(0, 153, 204));
        btStartPolling.setText("Start Polling");
        btStartPolling.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btStartPollingActionPerformed(evt);
            }
        });

        btStopPolling.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btStopPolling.setForeground(new java.awt.Color(0, 153, 204));
        btStopPolling.setText("Stop Polling");
        btStopPolling.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btStopPollingActionPerformed(evt);
            }
        });

        etHost.setBackground(new java.awt.Color(255, 255, 255));
        etHost.setForeground(new java.awt.Color(0, 153, 204));
        etHost.setText("Choose host IP: ");
        etHost.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        etHost.setOpaque(true);

        cbHosts.setBackground(new java.awt.Color(255, 255, 255));
        cbHosts.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cbHostsItemStateChanged(evt);
            }
        });
        cbHosts.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbHostsActionPerformed(evt);
            }
        });

        btHostInfo.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btHostInfo.setForeground(new java.awt.Color(0, 153, 204));
        btHostInfo.setText("Host Info");
        btHostInfo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btHostInfoActionPerformed(evt);
            }
        });

        pComputation.setBackground(new java.awt.Color(255, 255, 255));
        pComputation.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED, new java.awt.Color(0, 153, 204), new java.awt.Color(0, 153, 204), null, null), "Computing Stats", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Dialog", 0, 12), new java.awt.Color(0, 153, 204))); // NOI18N
        pComputation.setForeground(new java.awt.Color(0, 153, 204));
        pComputation.setPreferredSize(new java.awt.Dimension(175, 108));

        btCPULoad.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(btCPULoad);
        btCPULoad.setText("CPU Load (%)");

        btRAMUsg.setBackground(new java.awt.Color(255, 255, 255));
        buttonGroup2.add(btRAMUsg);
        btRAMUsg.setText("RAM Usage (%)");
        btRAMUsg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btRAMUsgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pComputationLayout = new javax.swing.GroupLayout(pComputation);
        pComputation.setLayout(pComputationLayout);
        pComputationLayout.setHorizontalGroup(
            pComputationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pComputationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pComputationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btRAMUsg, javax.swing.GroupLayout.DEFAULT_SIZE, 137, Short.MAX_VALUE)
                    .addGroup(pComputationLayout.createSequentialGroup()
                        .addComponent(btCPULoad)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pComputationLayout.setVerticalGroup(
            pComputationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pComputationLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(btCPULoad)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btRAMUsg)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btCompute.setFont(new java.awt.Font("Liberation Sans", 1, 14)); // NOI18N
        btCompute.setForeground(new java.awt.Color(0, 153, 204));
        btCompute.setText("Compute Graph");
        btCompute.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btComputeActionPerformed(evt);
            }
        });

        mbMenu.setBackground(java.awt.Color.gray);

        jMenu1.setText("File");

        miExit.setText("Exit");
        miExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miExitActionPerformed(evt);
            }
        });
        jMenu1.add(miExit);

        mbMenu.add(jMenu1);

        jMenu2.setText("Help");

        miAbout.setText("About");
        miAbout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                miAboutActionPerformed(evt);
            }
        });
        jMenu2.add(miAbout);

        mbMenu.add(jMenu2);

        setJMenuBar(mbMenu);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(79, 79, 79)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(etHost)
                            .addComponent(btStartPolling)
                            .addComponent(btStopPolling)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(etPort, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(etSwitch, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbSwitches, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btTrafficGraph, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(pTrafficStats, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(34, 34, 34)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(pComputation, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btCompute, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(cbHosts, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(cbPort, javax.swing.GroupLayout.Alignment.LEADING, 0, 193, Short.MAX_VALUE)))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btTopoInfo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btHostInfo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btNetInfo, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btFlowRules, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(spInfo)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(etTime)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spTime, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(etSwitch)
                    .addComponent(cbSwitches, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(etTime)
                    .addComponent(spTime, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(spInfo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                            .addComponent(btTopoInfo)
                            .addComponent(btNetInfo)
                            .addComponent(btFlowRules)
                            .addComponent(btHostInfo)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etPort)
                            .addComponent(cbPort, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(etHost)
                            .addComponent(cbHosts, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 54, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(btStartPolling)
                                .addGap(18, 18, 18)
                                .addComponent(btStopPolling))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(pTrafficStats, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(pComputation, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btCompute)
                                    .addComponent(btTrafficGraph))))))
                .addGap(34, 34, 34))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Método para determinar la acción realizada por el JComboBox de elección
     * del switch (cbSwitch).
     *
     * @param evt
     */
    private void cbSwitchesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbSwitchesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbSwitchesActionPerformed

    /**
     * Método para identificar el cambio de estado de items en el JComboBox de
     * elección del switch (cbSwitch). Este método se encargará de cambiar
     * automáticamente los Items del JComboBox de elección de puertos del switch
     * (cbPort) en función del switch elegido en cbSwitch.
     *
     * @param evt
     */
    private void cbSwitchesItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbSwitchesItemStateChanged
        int sw = 0;
        if (evt.getStateChange() == ItemEvent.SELECTED && this.cbSwitches.getSelectedItem() != null) {
            for (int j = 0; j < list_sw.length; j++) {
                if (list_sw[j].equals(this.cbSwitches.getSelectedItem().toString())) {
                    sw = j;
                }
            }
            int ports = Integer.parseInt(num_ports_sw[sw]);
            String[] num_ports = new String[ports];
            for (int i = 0; i < num_ports.length; i++) {
                num_ports[i] = name_ports_sw[sw][i];
            }
            this.cbPort.setModel(new DefaultComboBoxModel(num_ports));
        }

        cbPort.setSelectedItem(null);
    }//GEN-LAST:event_cbSwitchesItemStateChanged

    /**
     * Método para determinar la acción realizada por el JComboBox de elección
     * del puerto del switch (cbPort).
     *
     * @param evt
     */
    private void cbPortActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbPortActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPortActionPerformed

    /**
     * Método para descubrir el número de puerto del OVSwitch asociado al nombre
     * de puerto seleccionado desde el JComboBox de elección del puerto del
     * switch (cbPort) de la GUI.
     *
     * @return
     */
    public String discoverNumPort() {

        int pos_sw = 0;
        int pos_port = 0;

        String num_port = new String();

        for (int i = 0; i < list_sw.length; i++) {
            if (list_sw[i].equals(this.cbSwitches.getSelectedItem().toString())) {
                pos_sw = i;
            }
        }

        for (int j = 0; j < Integer.parseInt(num_ports_sw[pos_sw]); j++) {
            if (name_ports_sw[pos_sw][j].equals(this.cbPort.getSelectedItem().toString())) {
                pos_port = j;
            }
        }

        for (int k = 0; k < list_ports_sw.length; k++) {
            if (k == pos_port) {
                num_port = list_ports_sw[pos_sw][pos_port];
            }
        }

        return num_port;
    }

    /**
     * Método para determinar la acción realizada por el botón "Traffic Graph"
     * de la GUI. Este botón se encargará de lanzar o poner en ejecución el
     * GUI_Graph para representar y analizar la monitorización de tráfico
     * realizada sobre el troughput de los switch OVS, dependiendo de la métrica
     * o estadística seleccionada desde su grupo de botones (JRadioButtons)
     * correspondientes, así como del switch y su puerto asociado elegidos.
     * Estas métricas son: Packet Rate y Byte Rate.
     *
     * Dependiendo de la métrica seleccionada (Packet Rate o Byte Rate) y el
     * tiempo de refresco (JSpinner) indicado, se instanciará un objeto de la
     * clase GUI_Graph con el archivo de la gráfica RRDTOOL y los datos o
     * métricas detalladas para analizar y visualizar la labor de monitorización
     * específica desarrollada para el switch OVS y puerto seleccionado. En caso
     * de que el usuario pulse el botón "Traffic Graph" sin haber empezado el
     * sondeo de monitorización de la red (Start Polling JButton) o sin haber
     * elegido antes una opción de monitorización o sin haber indicado el switch
     * y puerto asociados, se mostrará una ventana de error indicando al usuario
     * que seleccione una estadística de puerto.
     *
     * @param evt
     */
    private void btTrafficGraphActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTrafficGraphActionPerformed
        if ((this.cbSwitches.getSelectedItem() != null && this.cbPort.getSelectedItem() != null) && start_monitoring == true) {
            int time = Integer.parseInt(spTime.getValue().toString());
            String imagen = new String();
            String datos = new String();
            String title = new String();

            String[] split1 = this.cbSwitches.getSelectedItem().toString().split(":");
            String id_sw = split1[1];

            String id_port = discoverNumPort();
            String[] split2 = id_port.split(":");

            id_port = split2[2];

            if (btPckRate.isSelected()) {
                imagen = "../API_OpenPoll/rrdtool/traffic_stats/packet_rate/images/packet_rate_" + id_sw + "_" + id_port + ".png";
                datos = "../API_OpenPoll/rrdtool/traffic_stats/packet_rate/data_info/packet_rate_" + id_sw + "_" + id_port + ".txt";
                title = "Packet Rate (switch " + id_sw + " port " + id_port + ")";

                /*
                Instanciamos un objeto de la clase interfaz gráfica de usuario GUI_Graph que
                se encargará de visualizar la gráfica RRDTOOL con las métricas monitorizadas y de
                poder imprimir los resultados o cálculos provistos. Recibe por parámetro el tiempo de refresco,
                la imagen RRDTool, el fichero con los datos monitorizados y el título para el GUI. Además,
                recibe por parámetro el botón btStopPolling para cerrar la GUI_Graph en caso de detención de la monitorización.
                 */
                File file_img = new File(imagen);
                File file_data = new File(datos);
                if (file_img.exists() && file_data.exists()) {
                    GUI_Graph graph = new GUI_Graph(time, imagen, datos, title, btStopPolling);
                } else {
                    //JOptionPane.showMessageDialog(null, "Generando repositorios...", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                    JOptionPane.showMessageDialog(null, "Generating repositories...", "ERROR!", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                if (btByteRate.isSelected()) {
                    imagen = "../API_OpenPoll/rrdtool/traffic_stats/byte_rate/images/byte_rate_" + id_sw + "_" + id_port + ".png";
                    datos = "../API_OpenPoll/rrdtool/traffic_stats/byte_rate/data_info/byte_rate_" + id_sw + "_" + id_port + ".txt";
                    title = "Byte Rate (switch " + id_sw + " port " + id_port + ")";

                    /*
                    Instanciamos un objeto de la clase interfaz gráfica de usuario GUI_Graph que
                    se encargará de visualizar la gráfica RRDTOOL con las métricas monitorizadas y de
                    poder imprimir los resultados o cálculos provistos. Recibe por parámetro el tiempo de refresco,
                    la imagen RRDTool, el fichero con los datos monitorizados y el título para el GUI. Además,
                    recibe por parámetro el botón btStopPolling para cerrar la GUI_Graph en caso de detención de la monitorización.
                     */
                    File file_img = new File(imagen);
                    File file_data = new File(datos);
                    if (file_img.exists() && file_data.exists()) {
                        GUI_Graph graph = new GUI_Graph(time, imagen, datos, title, btStopPolling);
                    } else {
                        //JOptionPane.showMessageDialog(null, "Generando repositorios...", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                        JOptionPane.showMessageDialog(null, "Generating repositories...", "ERROR!", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    //JOptionPane.showMessageDialog(null, "Introduzca una estadística o métrica a monitorizar.", "¡ERROR!", JOptionPane.WARNING_MESSAGE);
                    JOptionPane.showMessageDialog(null, "Enter a metric to monitor.", "ERROR!", JOptionPane.WARNING_MESSAGE);
                }
            }
        } else {
            if (this.cbSwitches.getSelectedItem() == null || this.cbPort.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(null, "Choose a switch and a port number.", "ERROR!", JOptionPane.WARNING_MESSAGE);
            }

            if (start_monitoring == false) {
                JOptionPane.showMessageDialog(null, "You must 'Start Polling'.", "ERROR!", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_btTrafficGraphActionPerformed

    private void btPckRateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPckRateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btPckRateActionPerformed

    /**
     * Método para identificar el cambio de estado de items en el JComboBox de
     * elección de puertos del switch (cbPort).
     *
     * @param evt
     */
    private void cbPortItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbPortItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cbPortItemStateChanged

    /**
     * Método para determinar la acción realizada por el botón "Topology Info"
     * de la GUI. Si el usuario acciona este botón, se imprimirá información
     * detallada sobre el switch y puerto elegidos a monitorizar dentro del
     * JScrollPane. Para ello hace una llamada al método topologyInfo().
     *
     * @param evt
     */
    private void btTopoInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btTopoInfoActionPerformed
        if (this.cbSwitches.getSelectedItem() != null && this.cbPort.getSelectedItem() != null) {
            try {
                topologyInfo();
            } catch (IOException ex) {
                Logger.getLogger(GUI_Topology.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Choose a switch and a port number.", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btTopoInfoActionPerformed

    /**
     * Método para imprimir dentro del JScrollPane de la GUI información
     * detallada sobre el switch y puerto elegidos de la topología de red al
     * pulsar el botón "Topology Info". Este método se encargará de hacer
     * peticiones HTTP al controlador mediante la API REST para extraer
     * diferente información de interés de los switches y puertos. Parte de la
     * información adicional consultada es realizada por el método
     * additionalInfo() llamado desde este método. La información extraída será
     * almacenada en un ArrayList, la cuál se imprimirá en el JTextArea del
     * ScrollPane del GUI (TextArea de sólo lectura sobre el que imprimir toda
     * la información).
     */
    public void topologyInfo() throws IOException {
        if (num_sw >= 1) {
            String sw = this.cbSwitches.getSelectedItem().toString();
            String port_sw = this.cbPort.getSelectedItem().toString();
            String[] split1 = this.cbSwitches.getSelectedItem().toString().split(":");
            String id_sw = split1[1];

            String id_port = discoverNumPort();
            String[] split2 = id_port.split(":");

            ArrayList<String> sw_info = new ArrayList<String>();

            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes/node/openflow:" + id_sw + "/node-connector/openflow:" + id_sw + ":" + split2[2]};

            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            int i;
            JSONObject jso = new JSONObject();
            StringBuilder sb = new StringBuilder();
            boolean iniciojson = false;
            int cont = 0;

            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer.read()) != -1) {

                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }

            try {

                /*
                    Recogemos la muestra en un JSONObject y hallaremos los campos necesarios 
                    con el método .get() para calcular las métricas:
                 */
                jso = new JSONObject(sb.toString());

                sw_info = additionalInfo(sw_info, id_sw);

                String[] idsw = jso.get("id").toString().split(":");

                sw_info.add("Switch ID: " + idsw[0] + ":" + idsw[1]);

                sw_info.add("Port ID: " + jso.get("id").toString());

                sw_info.add("Port number: " + jso.get("flow-node-inventory:port-number").toString());

                sw_info.add("Port name: " + jso.get("flow-node-inventory:name").toString());

                sw_info.add("Port Hardware Address: " + jso.get("flow-node-inventory:hardware-address").toString());

                sw_info.add("Port Current Speed: " + jso.get("flow-node-inventory:current-speed").toString());

                if (jso.has("address-tracker:addresses")) {
                    JSONArray hosts = new JSONArray(jso.get("address-tracker:addresses").toString());
                    for (int j = 0; j < hosts.length(); j++) {
                        JSONObject host = new JSONObject(hosts.getJSONObject(j).toString());
                        sw_info.add("Host " + j);
                        sw_info.add("  ID: " + host.get("id").toString());
                        sw_info.add("  IP address: " + host.get("ip").toString());
                        sw_info.add("  MAC address: " + host.get("mac").toString());
                    }
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }

            jtx = new JTextArea();
            jtx.setEditable(false);
            spInfo.setViewportView(jtx);

            for (int k = 0; k < sw_info.size(); k++) {
                jtx.append(sw_info.get(k));
                jtx.append(System.getProperty("line.separator"));
            }

        }
    }

    /**
     * Método con información adicional sobre los switches OVS de la topología
     * de red SDN, llamado desde el método topologyInfo(). Este método se
     * encargará de hacer peticiones HTTP al controlador mediante la API REST
     * para extraer la información adicional
     *
     * @param sw_info
     * @param id_sw
     * @return
     * @throws IOException
     */
    public ArrayList<String> additionalInfo(ArrayList<String> sw_info, String id_sw) throws IOException {
        String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes/node/openflow:" + id_sw};

        Process process = Runtime.getRuntime().exec(request);
        InputStream input = process.getInputStream();
        BufferedInputStream buffer = new BufferedInputStream(input);
        int i;
        JSONObject jso = new JSONObject();
        StringBuilder sb = new StringBuilder();
        boolean iniciojson = false;
        int cont = 0;
        /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
         */
        while ((i = buffer.read()) != -1) {

            if ((char) i == '{') {
                cont++;
            }
            if (cont == 2) {
                iniciojson = true;
            }
            if (iniciojson == true) {
                sb.append((char) i);
            }
        }

        try {

            /*
                    Recogemos la muestra en un JSONObject y hallaremos los campos necesarios 
                    con el método .get() para calcular las métricas:
             */
            jso = new JSONObject(sb.toString());

            sw_info.add("IP node address: " + jso.get("flow-node-inventory:ip-address").toString());

            sw_info.add("Switch hardware info: " + jso.get("flow-node-inventory:hardware").toString());

            sw_info.add("Switch software info: " + jso.get("flow-node-inventory:software").toString());

            sw_info.add("Switch Manufacturer info: " + jso.get("flow-node-inventory:manufacturer").toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return sw_info;

    }

    /**
     * Método para determinar la acción realizada por el item Exit(jMenuItem)
     * del menú File perteneciente a la barra de herramientas (JMenuBar)
     * asociada a la interfaz. La opción Exit se encargará de avisar al usuario,
     * a través de una ventana de confirmación, de si efectivamente desea salir
     * o no del programa, en caso de que el usario la seleccione previamente.
     * (Misma acción que el método closeProgram()).
     *
     * @param evt
     */
    private void miExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miExitActionPerformed
        //int n = JOptionPane.showConfirmDialog(null, "¿Desea salir del programa?", "¡AVISO!", JOptionPane.YES_NO_OPTION);
        int n = JOptionPane.showConfirmDialog(null, "Do you want to exit the program?", "NOTICE!", JOptionPane.YES_NO_OPTION);

        if (n == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_miExitActionPerformed

    /**
     * Método para determinar la acción realizada por el item About(jMenuItem)
     * del menú Help perteneciente a la barra de herramientas (JMenuBar)
     * asociada a la interfaz. En caso de que el usuario seleccione la opción
     * About, el programa mostrará una ventana informativa con el nombre de la
     * aplicación así como un email de contacto.
     *
     * @param evt
     */
    private void miAboutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_miAboutActionPerformed
        JOptionPane.showMessageDialog(null, "OpenPoll: API to poll metrics information of SDN infrastructures in OpenStack scenarios. \n\n" + "Author: Daniel González Sánchez\n" + "email: daniel.gonzalez.sanchez@alumnos.upm.es", "ABOUT", JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_miAboutActionPerformed

    /**
     * Método para imprimir dentro del JScrollPane de la GUI información
     * detallada sobre recursos de redes virtuales instanciados en la
     * infraestructura de red OpenStack, accionado al pulsar el botón "Network
     * Info". Este método se encargará de hacer llamada a otro método,
     * dependiendo de la opción elegida sobre consulta de recursos virtuales
     * creados. Las tres opciones disponibles son: información de redes
     * virtuales (networks), información de subredes virtuales (subnetworks) e
     * información de routers virtuales (routers). Según la opción elegida
     * (desde un nuevo JFrame) y el método asociado, se realizarán distintas
     * peticiones HTTP al controlador mediante la API REST para extraer
     * diferente información sobre el recurso de red virtual en cuestión.
     *
     * @param evt
     */
    private void btNetInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btNetInfoActionPerformed

        JFrame frame = new JFrame("Network info options");

        String[] options = {"networks", "subnetworks", "routers"};

        String selection = (String) JOptionPane.showInputDialog(frame, "Select an option to check: ", "Network info options", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        if (selection != null) {
            switch (selection) {
                case "networks":
                    networkInfo();
                    break;
                case "subnetworks":
                    subnetInfo();
                    break;
                case "routers":
                    routerInfo();
                    break;
            }
        }
    }//GEN-LAST:event_btNetInfoActionPerformed

    /**
     * Método para imprimir dentro del JScrollPane de la GUI información
     * detallada sobre los recursos de redes virtuales "networks" consultados,
     * llamado desde el método btNetInfoActionPerformed(). Este método se
     * encargará de hacer peticiones HTTP al controlador mediante la API REST
     * para extraer diferente información sobre las redes virtuales instanciadas
     * en OpenStack. La información extraída será almacenada en un ArrayList, la
     * cuál se imprimirá en el JTextArea del ScrollPane del GUI (TextArea de
     * sólo lectura sobre el que imprimir toda la información).
     */
    public void networkInfo() {

        ArrayList<String> net_info = new ArrayList<String>();

        try {

            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/controller/nb/v2/neutron/networks"};

            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            int i;
            JSONObject json = new JSONObject();
            JSONArray networks = new JSONArray();
            StringBuilder sb = new StringBuilder();
            boolean iniciojson = false;

            while ((i = buffer.read()) != -1) {
                sb.append((char) i);
            }

            json = new JSONObject(sb.toString());
            networks = new JSONArray(json.get("networks").toString());
            for (int j = 0; j < networks.length(); j++) {
                JSONObject network = new JSONObject(networks.getJSONObject(j).toString());

                net_info.add("-------------------------------------------------------------------------------------------");

                net_info.add("Network " + (j + 1) + "\n");

                net_info.add("  -Name: " + network.get("name").toString());

                net_info.add("  -Network ID: " + network.get("id").toString());

                net_info.add("  -Tenant ID: " + network.get("tenant_id").toString());

                net_info.add("  -Network Type: " + network.get("provider:network_type").toString());

                if (network.has("provider:segmentation_id")) {
                    net_info.add("  -Segmentation ID (VXLAN Network ID): " + network.get("provider:segmentation_id").toString());
                }

                if (network.has("provider:physical_network")) {
                    net_info.add("  -Provider Physical Network : " + network.get("provider:physical_network").toString());
                }

                net_info.add("  -Shared: " + network.get("shared").toString());

                net_info.add("  -Router External: " + network.get("router:external").toString());

                net_info.add("  -Status: " + network.get("status").toString());

                net_info.add("  -Admin state: " + network.get("admin_state_up").toString());

                net_info.add("-------------------------------------------------------------------------------------------");

                net_info.add("\n");
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }

        jtx = new JTextArea();
        jtx.setEditable(false);
        jtx.setText("");
        spInfo.setViewportView(jtx);

        for (int k = 0; k < net_info.size(); k++) {
            jtx.append(net_info.get(k));
            jtx.append(System.getProperty("line.separator"));
        }

        jtx.setCaretPosition(0);
    }

    /**
     * Método para imprimir dentro del JScrollPane de la GUI información
     * detallada sobre los recursos de redes virtuales "subnetworks"
     * consultados, llamado desde el método btNetInfoActionPerformed(). Este
     * método se encargará de hacer peticiones HTTP al controlador mediante la
     * API REST para extraer diferente información sobre las subredes virtuales
     * instanciadas en OpenStack. La información extraída será almacenada en un
     * ArrayList, la cuál se imprimirá en el JTextArea del ScrollPane del GUI
     * (TextArea de sólo lectura sobre el que imprimir toda la información).
     */
    public void subnetInfo() {

        ArrayList<String> subnet_info = new ArrayList<String>();

        try {

            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/controller/nb/v2/neutron/subnets"};

            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            int i;
            JSONObject json = new JSONObject();
            JSONArray subnets = new JSONArray();
            StringBuilder sb = new StringBuilder();
            boolean iniciojson = false;

            while ((i = buffer.read()) != -1) {
                sb.append((char) i);
            }

            json = new JSONObject(sb.toString());
            subnets = new JSONArray(json.get("subnets").toString());
            for (int j = 0; j < subnets.length(); j++) {
                JSONObject subnet = new JSONObject(subnets.getJSONObject(j).toString());

                subnet_info.add("-------------------------------------------------------------------------------------------");

                subnet_info.add("Subnet " + (j + 1) + "\n");

                subnet_info.add("   -Name: " + subnet.get("name").toString());

                subnet_info.add("   -Network ID: " + subnet.get("network_id").toString());

                subnet_info.add("   -Subnetwork ID: " + subnet.get("id").toString());

                subnet_info.add("   -Tenant ID: " + subnet.get("tenant_id").toString());

                subnet_info.add("   -IP version: " + subnet.get("ip_version").toString());

                subnet_info.add("   -CIDR based addressing: " + subnet.get("cidr").toString());

                subnet_info.add("   -Gateway IP: " + subnet.get("gateway_ip").toString());

                subnet_info.add("   -DNS servers: " + subnet.get("dns_nameservers").toString());

                subnet_info.add("   -Allocation pools: ");

                JSONArray pools = new JSONArray(subnet.get("allocation_pools").toString());
                
                for (int k = 0; k < pools.length(); k++) {

                    String pool_start = pools.getJSONObject(k).get("start").toString();

                    String pool_end = pools.getJSONObject(k).getString("end").toString();

                    subnet_info.add("       ->Allocation pool " + (k + 1) + ": " + pool_start + " - " + pool_end);

                }
                
                subnet_info.add("   -Enable DHCP: " + subnet.get("enable_dhcp").toString());
                
                subnet_info.add("-------------------------------------------------------------------------------------------");
                
                subnet_info.add("\n");
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }

        jtx = new JTextArea();
        jtx.setEditable(false);
        jtx.setText("");
        spInfo.setViewportView(jtx);

        for (int k = 0; k < subnet_info.size(); k++) {
            jtx.append(subnet_info.get(k));
            jtx.append(System.getProperty("line.separator"));
        }
        jtx.setCaretPosition(0);
    }

    /**
     * Método para imprimir dentro del JScrollPane de la GUI información
     * detallada sobre los recursos de redes virtuales "routers" consultados,
     * llamado desde el método btNetInfoActionPerformed(). Este método se
     * encargará de hacer peticiones HTTP al controlador mediante la API REST
     * para extraer diferente información sobre los routers virtuales
     * instanciadas en OpenStack. La información extraída será almacenada en un
     * ArrayList, la cuál se imprimirá en el JTextArea del ScrollPane del GUI
     * (TextArea de sólo lectura sobre el que imprimir toda la información).
     */
    public void routerInfo() {

        ArrayList<String> router_info = new ArrayList<String>();

        try {

            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/controller/nb/v2/neutron/routers"};

            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            int i;
            JSONObject json = new JSONObject();
            JSONArray routers = new JSONArray();
            StringBuilder sb = new StringBuilder();
            boolean iniciojson = false;

            while ((i = buffer.read()) != -1) {
                sb.append((char) i);
            }

            json = new JSONObject(sb.toString());
            routers = new JSONArray(json.get("routers").toString());
            for (int j = 0; j < routers.length(); j++) {
                JSONObject router = new JSONObject(routers.getJSONObject(j).toString());

                router_info.add("-------------------------------------------------------------------------------------------");

                router_info.add("Router " + (j + 1) + "\n");

                router_info.add("   -Name: " + router.get("name").toString());

                router_info.add("   -Router ID: " + router.get("id").toString());

                router_info.add("   -Tenant ID: " + router.get("tenant_id").toString());

                router_info.add("   -Distributed: " + router.get("distributed").toString());

                JSONObject gw_info = new JSONObject(router.get("external_gateway_info").toString());

                router_info.add("   -Network ID: " + gw_info.get("network_id").toString());

                router_info.add("   -Enable SNAT: " + gw_info.get("enable_snat").toString());

                router_info.add("   -External Fixed IPs: ");

                JSONArray external_fixed_ips = new JSONArray(gw_info.getJSONArray("external_fixed_ips").toString());

                for (int k = 0; k < external_fixed_ips.length(); k++) {
                    router_info.add("       ->External Fixed IP " + (k + 1) + ":");
                    router_info.add("           -IP address: " + external_fixed_ips.getJSONObject(k).get("ip_address").toString());
                    router_info.add("           -Subnetwork ID: " + external_fixed_ips.getJSONObject(k).get("subnet_id").toString());
                }

                router_info.add("   -Gateway port id: " + router.get("gw_port_id").toString());

                router_info.add("   -Admin state: " + router.get("admin_state_up").toString());

                router_info.add("-------------------------------------------------------------------------------------------");

                router_info.add("\n");
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }

        jtx = new JTextArea();
        jtx.setEditable(false);
        jtx.setText("");
        spInfo.setViewportView(jtx);

        for (int k = 0; k < router_info.size(); k++) {
            jtx.append(router_info.get(k));
            jtx.append(System.getProperty("line.separator"));
        }

        jtx.setCaretPosition(0);
    }

    /**
     * Método para poder mostrar información sobre las tablas de flujo de los
     * switches OVS del plano de datos SDN, accionado al pulstar el botón "Flow
     * Info" de la GUI. Hace una llamada al método flowTables() con la lógica de
     * consulta de información de las tablas de flujo OpenFlow.
     *
     * @param evt
     */
    private void btFlowRulesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btFlowRulesActionPerformed
        if (this.cbSwitches.getSelectedItem() != null) {
            flowTables();
        } else {
            JOptionPane.showMessageDialog(null, "Choose a switch to check its flows.", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btFlowRulesActionPerformed

    /**
     * Método para activar el comienzo de la monitorización por sondeo de la
     * infraestructura de red OpenStack gestionada por OpenDayLight. Se activa
     * al pulsar el botón "Start Polling", haciendo una llamada al método
     * solicitudesMonitorizacion().
     *
     * @param evt
     */
    private void btStartPollingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btStartPollingActionPerformed
        solicitudesMonitorizacion(btStopPolling);
    }//GEN-LAST:event_btStartPollingActionPerformed

    /**
     * Método para desactivar la monitorización por sondeo de la infraestructura
     * de red OpenStack gestionada por OpenDayLight. Se desactiva al pulsar el
     * botón "Stop Polling"
     *
     * @param evt
     */
    private void btStopPollingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btStopPollingActionPerformed
        start_monitoring = false;
    }//GEN-LAST:event_btStopPollingActionPerformed

    /**
     * Método para identificar el cambio de estado de items en el JComboBox de
     * elección del host (cbHost). Este método se encargará internamente de
     * cambiar los Items del JComboBox de elección de IP de hosts (cbHosts).
     *
     * @param evt
     */
    private void cbHostsItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cbHostsItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_cbHostsItemStateChanged


    private void cbHostsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbHostsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbHostsActionPerformed

    /**
     * Método para determinar la acción realizada por el botón "Host Info" del
     * GUI. Si el usuario acciona este botón, se imprimirá información de
     * cómputo general sobre el host de gestión elegido a monitorizar dentro del
     * JScrollPane. Se encarga de lanzar la ejecución de un Shell Script que
     * realiza peticiones por el protocolo de gestión SNMP para obtener ciertos
     * parámetros básicos de gestión de cómputo dada la IP de un host específico
     * de la infraestructura seleccionada desde el GUI. La información
     * consultada será almacenada en un fichero de texto para luego imprimirla
     * en el JScrollPane.
     *
     * @param evt
     */
    private void btHostInfoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btHostInfoActionPerformed
        if (this.cbHosts.getSelectedItem() != null) {
            this.setCursor(Cursor.WAIT_CURSOR);
            ArrayList<String> info = new ArrayList<String>();
            Ficheros f = new Ficheros();
            String ip = this.cbHosts.getSelectedItem().toString();
            String[] script = {"/bin/sh", "-c", "cd " + "../API_OpenPoll/rrdtool/computation_stats/; ./gestor_snmp.sh " + ip};
            Process process = null;
            StringBuilder data_info = new StringBuilder();
            try {
                process = Runtime.getRuntime().exec(script);
                InputStream input = process.getInputStream();
                BufferedInputStream buffer = new BufferedInputStream(input);
                int i = 0;
                while ((i = buffer.read()) != -1) {
                    data_info.append((char) i);
                }
                buffer.close();
                input.close();
            } catch (IOException ex) {
                Logger.getLogger(GUI_Topology.class.getName()).log(Level.SEVERE, null, ex);
            }

            String fichero = "../API_OpenPoll/rrdtool/computation_stats/snmp_info.txt";
            f.escribirFichero(fichero, data_info.toString());
            info = f.leerFicheroSNMP(fichero);

            Object[][] datos = new Object[info.size()][2];

            for (int i = 0; i < info.size(); i++) {
                String s = info.get(i);
                String[] split = s.split(": ");
                for (int j = 0; j < 2; j++) {
                    if (j == 0) {
                        datos[i][j] = split[0];
                    } else {
                        datos[i][j] = split[1];
                    }
                }
            }
            this.setCursor(Cursor.DEFAULT_CURSOR);
            String[] nombres = {"Statistic", "Information"};
            tabla = new JTable(datos, nombres);
            spInfo.setViewportView(tabla);
        } else {
            JOptionPane.showMessageDialog(null, "Choose a host IP.", "ERROR!", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btHostInfoActionPerformed

    private void btRAMUsgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btRAMUsgActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btRAMUsgActionPerformed

    /**
     * Método para determinar la acción realizada por el botón "Computing Stats"
     * de la GUI. Se ecargará de poner en ejecución la clase GUI_Graph para
     * poder ver las gráficas RRDTOOL y las estadísticas o metricas de
     * monitorización de cómputo realizadas en relación a un nodo de gestión de
     * la infraestructura OpenStack.
     *
     * @param evt
     */
    private void btComputeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btComputeActionPerformed
        if (this.cbHosts.getSelectedItem() != null && start_monitoring == true) {
            int time = Integer.parseInt(spTime.getValue().toString());
            String imagen = new String();
            String datos = new String();
            String title = new String();

            if (btCPULoad.isSelected()) {

                imagen = "../API_OpenPoll/rrdtool/computation_stats/cpu_load/images/cpu_load_" + this.cbHosts.getSelectedItem().toString() + ".png";
                datos = "../API_OpenPoll/rrdtool/computation_stats/cpu_load/data_info/cpu_load_" + this.cbHosts.getSelectedItem().toString() + ".txt";
                title = "Load CPU (Host " + cbHosts.getSelectedItem().toString() + ")";
                /*
                Instanciamos un objeto de la clase interfaz gráfica de usuario GUI_Graph que
                se encargará de visualizar la gráfica RRDTOOL con las métricas monitorizadas y de
                poder imprimir los resultados o cálculos provistos. Recibe por parámetro el tiempo de refresco,
                la imagen RRDTool, el fichero con los datos monitorizados y el título para el GUI. Además,
                recibe por parámetro el botón btStopPolling para cerrar la GUI_Graph en caso de detención de la monitorización.
                 */
                File file_img = new File(imagen);
                File file_data = new File(datos);
                if (file_img.exists() && file_data.exists()) {
                    GUI_Graph graph = new GUI_Graph(time, imagen, datos, title, btStopPolling);
                } else {
                    JOptionPane.showMessageDialog(null, "Generating repositories...", "ERROR!", JOptionPane.WARNING_MESSAGE);
                }
            } else {
                if (btRAMUsg.isSelected()) {

                    imagen = "../API_OpenPoll/rrdtool/computation_stats/ram_usage/images/ram_usage_" + cbHosts.getSelectedItem().toString() + ".png";
                    datos = "../API_OpenPoll/rrdtool/computation_stats/ram_usage/data_info/ram_usage_" + cbHosts.getSelectedItem().toString() + ".txt";
                    title = "Usage RAM (Host " + cbHosts.getSelectedItem().toString() + ")";
                    
                    /*
                    Instanciamos un objeto de la clase interfaz gráfica de usuario GUI_Graph que
                    se encargará de visualizar la gráfica RRDTOOL con las métricas monitorizadas y de
                    poder imprimir los resultados o cálculos provistos. Recibe por parámetro el tiempo de refresco,
                    la imagen RRDTool, el fichero con los datos monitorizados y el título para el GUI. Además,
                    recibe por parámetro el botón btStopPolling para cerrar la GUI_Graph en caso de detención de la monitorización.
                     */
                    File file_img = new File(imagen);
                    File file_data = new File(datos);
                    if (file_img.exists() && file_data.exists()) {
                        GUI_Graph graph = new GUI_Graph(time, imagen, datos, title, btStopPolling);
                    } else {
                        JOptionPane.showMessageDialog(null, "Generating repositories...", "ERROR!", JOptionPane.WARNING_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Enter a metric to monitor.", "ERROR!", JOptionPane.WARNING_MESSAGE);
                }
            }
        } else {

            if (this.cbHosts.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(null, "Choose a host IP.", "ERROR!", JOptionPane.WARNING_MESSAGE);
            }

            if (start_monitoring == false) {
                JOptionPane.showMessageDialog(null, "You must 'Start Polling'.", "ERROR!", JOptionPane.WARNING_MESSAGE);
            }
        }
    }//GEN-LAST:event_btComputeActionPerformed

    /**
     * Método para poder recoger y mostrar la información de las entradas de
     * flujo asociadas a la tabla de flujo seleccionada al pulsar el botón Flow
     * Info de la GUI. Este método es llamado por el método flowTables() que se
     * encarga de hallar las tablas de flujo activas en los OVSwitches y
     * permitir al usuario consultar las entradas de flujo sobre una tabla
     * seleccionada (esta última labor realizada por showFlowEntries()). El
     * método realizará una nueva consulta HTTP a partir de la API REST de
     * OpenDayLight para obtener y almacenar los campos de información de
     * aquellas entradas de flujo activas en la tabla previamente seleccionada.
     * La información de cada entrada de flujo es almacenada en una matriz de
     * String. Una vez extraída toda la información, se hace una llamada a la
     * clase GUI_FlowRules, que permite representar los campos de información de
     * las entradas de flujo ordenadamente en una tabla (JTable) sobre una nueva
     * interfaz GUI JFrame.
     *
     * @param table_flows
     */
    public void showFlowEntries(String table_flows) {
        try {
            String sw = this.cbSwitches.getSelectedItem().toString();
            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes"};
            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            StringBuilder sb = new StringBuilder();
            String[][] flow_stats = new String[0][10];
            int i;
            boolean iniciojson = false;
            int cont = 0;
            int active_flows = 0;
            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer.read()) != -1) {
                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }
            iniciojson = false;

            buffer.close();
            input.close();

            String switches_stats = sb.toString();

            StringBuilder sb2 = new StringBuilder();
            try {
                /*
                Recogemos la información en un JSONObject y hallaremos los datos necesarios 
                con el método .get():
                 */
                JSONObject jsonobj = new JSONObject(switches_stats);

                JSONArray nodes = new JSONArray(jsonobj.get("node").toString());
                for (int j = 0; j < nodes.length(); j++) {
                    JSONObject node = new JSONObject(nodes.getJSONObject(j).toString());
                    if (sw.equals(node.get("id").toString())) {

                        JSONArray tables = new JSONArray(node.get("flow-node-inventory:table").toString());
                        for (int k = 0; k < tables.length(); k++) {
                            JSONObject table = new JSONObject(tables.getJSONObject(k).toString());

                            //System.out.println(table.names());
                            JSONObject flowtablestats = new JSONObject(table.get("opendaylight-flow-table-statistics:flow-table-statistics").toString());
                            if (table_flows.equals(table.get("id").toString())/*Integer.parseInt(flowtablestats.get("active-flows").toString()) > 0*/) {

                                active_flows = Integer.parseInt(flowtablestats.get("active-flows").toString());
                                flow_stats = new String[active_flows][10];

                                JSONArray flows = new JSONArray(table.get("flow").toString());
                                for (int l = 0; l < flows.length(); l++) {

                                    JSONObject flow = new JSONObject(flows.getJSONObject(l).toString());

                                    flow_stats[l][0] = Integer.toString(l + 1);

                                    flow_stats[l][1] = flow.get("id").toString();

                                    flow_stats[l][2] = flow.get("cookie").toString();

                                    flow_stats[l][3] = flow.get("idle-timeout").toString();

                                    flow_stats[l][4] = flow.get("hard-timeout").toString();

                                    JSONObject flowstats = new JSONObject(flow.get("opendaylight-flow-statistics:flow-statistics").toString());
                                    JSONObject flowduration = new JSONObject(flowstats.get("duration").toString());

                                    flow_stats[l][5] = flowduration.get("second").toString();

                                    flow_stats[l][6] = flowstats.get("packet-count").toString();

                                    flow_stats[l][7] = flowstats.get("byte-count").toString();

                                    flow_stats[l][8] = flow.get("priority").toString();

                                    /*if (!flow.get("match").toString().equals("{}")) {
                                        flow_stats[l][9] = flow.get("match").toString();
                                    } else {
                                        flow_stats[l][9] = "-";
                                    }*/

                                    /*boolean instructions = false;
                                    for (int m = 0; m < flow.names().length(); m++) {
                                        if (flow.names().getString(m).equals("instructions")) {
                                            instructions = true;
                                        }
                                    }*/

                                     /*if (instructions == true) {
                                        flow_stats[l][10] = flow.get("instructions").toString();
                                    } else {
                                        flow_stats[l][10] = "-";
                                    }*/
                                    if (/*!flow.get("flags").toString().equals("")*/flow.get("flags").toString().length() > 0) {
                                        flow_stats[l][9] = flow.get("flags").toString();
                                    } else {
                                        flow_stats[l][9] = "-";
                                    }

                                }
                            }
                        }
                    }
                }

                JTable tabla;
                String[] nombres = {"nº flow", "flow entry id", "cookie", "idle-timeout", "hard-timeout", "duration(s)", /*"duration(ns)",*/ "packets", "bytes", "priority"/*, "matches", "instructions"*/, "flags"};
                tabla = new JTable(flow_stats, nombres);

                GUI_FlowRules gfr = new GUI_FlowRules(ipaddress, port, sw, table_flows, flow_stats, nombres, active_flows);

            } catch (JSONException e) {
                System.err.println(e);
                e.printStackTrace();
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }
    
    /**
     * Método encargado de extraer las tablas de flujo OpenFlow de los switches
     * OVS con entradas de flujo activas. Se encargará de hacer una petición
     * HTTP a partir de la API REST de OpenDayLight para poder determinar
     * aquellas tablas de flujo con entradas asociadas para el switch OVS
     * seleccionado. Una vez recogidas, el usuario podrá elegir desde un nuevo
     * JFrame aquella de las tablas sobre la que quiere consultar las entradas
     * de flujo con información por cada uno de sus campos (llamada al método
     * showFlowEntries()).
     */
    public void flowTables() {
        try {
            String sw = this.cbSwitches.getSelectedItem().toString();
            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes"};
            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            StringBuilder sb = new StringBuilder();
            Vector<String> tableflows = new Vector<String>();
            int active_flows = 0;

            int i;
            boolean iniciojson = false;
            int cont = 0;
            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer.read()) != -1) {
                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }
            iniciojson = false;

            buffer.close();
            input.close();

            String switches_stats = sb.toString();

            StringBuilder sb2 = new StringBuilder();
            try {
                /*
                Recogemos la información en un JSONObject y hallaremos los datos necesarios 
                con el método .get():
                 */
                JSONObject jsonobj = new JSONObject(switches_stats);

                //System.out.println(jsonobj.names());
                JSONArray nodes = new JSONArray(jsonobj.get("node").toString());
                for (int j = 0; j < nodes.length(); j++) {
                    JSONObject node = new JSONObject(nodes.getJSONObject(j).toString());

                    if (sw.equals(node.get("id").toString())) {

                        JSONArray tables = new JSONArray(node.get("flow-node-inventory:table").toString());
                        for (int k = 0; k < tables.length(); k++) {
                            JSONObject table = new JSONObject(tables.getJSONObject(k).toString());
                            JSONObject flowtablestats = new JSONObject(table.get("opendaylight-flow-table-statistics:flow-table-statistics").toString());
                            if (Integer.parseInt(flowtablestats.get("active-flows").toString()) > 0) {
                                tableflows.add(table.get("id").toString());
                                active_flows = Integer.parseInt(flowtablestats.get("active-flows").toString());
                            }
                        }
                    }
                }

                JFrame frame = new JFrame("Flow Tables");
                String selection = (String) JOptionPane.showInputDialog(frame, "Select a flow table: ", "Flow Tables", JOptionPane.QUESTION_MESSAGE, null, tableflows.toArray(), tableflows.toArray()[0]);

                if (selection != null) {
                    this.setCursor(Cursor.WAIT_CURSOR);
                    showFlowEntries(selection);
                    this.setCursor(Cursor.DEFAULT_CURSOR);
                }

            } catch (JSONException e) {
                System.err.println(e);
                e.printStackTrace();
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton btByteRate;
    private javax.swing.JRadioButton btCPULoad;
    private javax.swing.JButton btCompute;
    private javax.swing.JButton btFlowRules;
    private javax.swing.JButton btHostInfo;
    private javax.swing.JButton btNetInfo;
    private javax.swing.JRadioButton btPckRate;
    private javax.swing.JRadioButton btRAMUsg;
    private javax.swing.JButton btStartPolling;
    private javax.swing.JButton btStopPolling;
    private javax.swing.JButton btTopoInfo;
    private javax.swing.JButton btTrafficGraph;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JComboBox<String> cbHosts;
    private javax.swing.JComboBox<String> cbPort;
    private javax.swing.JComboBox<String> cbSwitches;
    private javax.swing.JLabel etHost;
    private javax.swing.JLabel etPort;
    private javax.swing.JLabel etSwitch;
    private javax.swing.JLabel etTime;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar mbMenu;
    private javax.swing.JMenuItem miAbout;
    private javax.swing.JMenuItem miExit;
    private javax.swing.JPanel pComputation;
    private javax.swing.JPanel pTrafficStats;
    private javax.swing.JScrollPane spInfo;
    private javax.swing.JSpinner spTime;
    // End of variables declaration//GEN-END:variables
}
