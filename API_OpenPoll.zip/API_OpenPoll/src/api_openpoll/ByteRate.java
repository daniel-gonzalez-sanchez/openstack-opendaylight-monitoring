package api_openpoll;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Esta clase se encarga de realizar la monitorización de la red basada en la
 * métrica Byte Rate de la categoría Traffic Statistics.
 *
 * Esta métrica permite extraer el rango de bytes transmitidos y recibidos por
 * cada puerto de los Open vSwitch del plano de datos SDN. Se trata de una
 * métrica sobre el throughput o tasa de tráfico cursada en los enlaces de los
 * switches datapath, interpretada como medida de calidad de servicio de la red.
 *
 * Para ello, esta clase se encargará de realizar una solicitud HTTP al
 * controlador OpenDayLight de la red SDN a través de la API REST, solicitando
 * los datos necesarios para obtener el rango de bytes transmitidos y recibidos
 * de el puerto y el switch OVS indicados en cada instante de tiempo.
 *
 * Las métricas o estadísticas calculadas sobre rango de bytes serán almacenadas
 * en archivos .rrd de tipo RRDTOOL para luego ser representadas en gráficas que
 * serán visualizadas a partir de la clase GUI_Graph. Cierta información
 * estadística monitorizada también será almacenada en ficheros de texto para su
 * posterior uso y representación desde GUI_Graph.
 *
 * @author Daniel González Sánchez
 */
public class ByteRate {

    /**
     * Atributo para almacenar los bytes recibidos a través del puerto del
     * switch.
     */
    private long receivedBytes;

    /**
     * Atributo para almacenar los bytes transmitidos por el puerto del switch.
     */
    private long transmittedBytes;

    /**
     * Atributo para tomar el rango de bytes recibidos por segundo.
     */
    private double rx_byte_rate;

    /**
     * Atributo para tomar el rango de bytes transmitidos por segundo.
     */
    private double tx_byte_rate;

    /**
     * Atributo para almacenar la duración o tiempo de la muestra en segundos.
     */
    private int sample_duration;

    /**
     * Atributo para almacenar el campo duration(segundos) de los flujos
     * monitorizados.
     */
    private long duration_s;

    /**
     * Atributo para almacenar el campo duration(nanosegundos) de los flujos
     * monitorizados.
     */
    private long duration_ns;

    /**
     * Atributo para almacenar la IP asociada al controlador para establecer la
     * conexión a la API REST del controlador ODL y poder realizar las
     * peticiones HTTP.
     */
    private String ipaddress;

    /**
     * Atributo para almacenar el puerto asociado al controlador para establecer
     * la conexión a la API REST del controlador ODL y poder realizar las
     * peticiones HTTP.
     */
    private String port;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo entero donde almacenar el identificador del switch a
     * monitorizar.
     */
    private String id_sw;

    /**
     * Atributo entero donde almacenar el identificador del puerto del switch a
     * monitorizar.
     */
    private String id_port;

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Atributo entero para determinar el número de muestra de monitorización.
     * Variable para remarcar cúando se realiza la primera muestra de
     * monitorización. Esta primera muestra no será correcta debido a que no
     * conoceremos la que sería la muestra anterior de la métrica y por tanto
     * los cálculos no serían correctos. Por ello, RRDTOOL obviará la primera
     * muestra y no la recogerá en su base de datos ni la representará
     * gráficamente. Esta variable será recibida en el Shell Script de creación
     * y actualización de la base de datos RRD, de tal forma que para la primera
     * muestra recibirá un 1 y no actualizará la base de datos y para muestras
     * posteriores recibirá un 0 indicando que ya no es la muestra inicial y por
     * tanto se podrá actualizar RRD y representarse es su gráfica.
     */
    private int muestra_inicial;

    /**
     * Array List donde iremos almacenando los datos y métricas monitorizadas.
     */
    private ArrayList<String> info;

    /**
     * Constructor por defecto.
     */
    public ByteRate() {
        receivedBytes = 0;
        transmittedBytes = 0;
        sample_duration = 0;
        rx_byte_rate = 0;
        tx_byte_rate = 0;
        cerrar = false;
    }

    /**
     * Constructor parametrizado.
     *
     * @param ipaddress
     * @param port
     * @param time
     * @param id_sw
     * @param id_port
     * @param muestra_inicial
     */
    public ByteRate(String ipaddress, String port, int time, String id_sw, String id_port, int muestra_inicial) {
        this.ipaddress = ipaddress;
        this.port = port;
        this.time = time;
        this.id_sw = id_sw;
        this.id_port = id_port;
        this.muestra_inicial = muestra_inicial;
    }

    /**
     * Método con la lógica de las peticiones HTTP para extraer las métricas de
     * rango de bytes en monitorización basada en puertos del switch. Mediante
     * la API REST de OpenDayLight se realizará la petición HTTP correspondiente
     * al controlador SDN y se extraerán los datos necesarios para calcular la
     * métrica en cuestión.
     *
     * Este método será llamado desde la clase TrafficStats al seleccionar la
     * opción Byte Rate y el botón Traffic Graph de la GUI_Topology. Se
     * encargará de monitorizar el rango de bytes recibidos y transmitidos por
     * segundo en nuestra red SDN a través de un puerto de un switch
     * determinado.
     *
     * Esta clase recibe por parámetro la dirección IP y el puerto del
     * controlador necesarios para realizar las peticiones HTTP, así como el id
     * del switch y el id del puerto asociado para poder realizar la petición
     * HTTP por la API REST.
     *
     * La petición HTTP a través de la API REST se realiza lanzando un comando
     * Linux desde Java con el método Runtime.getRuntime().exec(). La petición
     * en ese caso es la siguiente: curl -u "admin:admin" -H "Accept:
     * application/json" -H "Content-type: application/json" -X GET
     * "http://{ipaddress}:{port}/restconf/
     * operational/opendaylight-inventory:nodes/node/openflow:{id_sw}/node-connector/
     * openflow:{id_sw}:{id_port}/opendaylight-port-statistics:query-capable-node-connector-statistics"
     * ,(donde id_sw e id_port serán los identificadores del switch OVS y puerto
     * asociado a monitorizar).
     *
     * Desde un buffer recogeremos la información proporcionada al realizar la
     * petición. Los datos de la respuesta son generados como objetos tipo JSON
     * propio de JavaScript. A partir del método .get() de los objetos JSON,
     * podremos filtrar la información necesaria para obtener los bytes
     * recibidos y transmitidos en cada instante de tiempo así como la duración
     * o timestap de la muestra. A partir de estos parámetros podremos obtener
     * el rango de bytes recibidos y transmitidos por cada puerto en un
     * intervalo de tiempo determinado. Este tiempo equivaldrá al tiempo de
     * sondeo que el usuario eligió en el GUI_Main inicial. Es decir, el tiempo
     * de cada muestra para hallar los rangos de bytes será igual al tiempo de
     * muestreo o polling time.
     *
     * Una vez monitorizados los datos necesarios para obtener la métrica, ya
     * podremos representar la gráfica. Para ello, deberemos generar la gráfica
     * RRDTOOL con los datos obtenidos. Lo primero será crear la base de datos
     * circular propia de RRDTOOl (Round Robin Database) siempre que no exista.
     * Una vez generada, se irá actualizando con los valores de las métricas que
     * se vayan obteniendo por cada muestra (comentar que el paso o toma de
     * datos en la Base de Datos está definida en un mínimo de 1 segundo). Por
     * último, se generará la gráfica según los valores registrados en la base
     * de datos a una escala e intervalo de tiempo determinada (se irán
     * mostrando los datos registrados durante los 10 últimos minutos). Las
     * funciones de creación, actualización de la base de datos RRDTOOL y la
     * generación de la gráfica están desarrolladas en 2 shell scripts
     * diferentes que se encuentra en el la carpeta del proyecto API_OpenPoll,
     * en el subdirectorio ../rddtool/traffic_stats/byte_rate/. Además, en ese
     * directorio se generarán la imagen de la gráfica RRDTOOL en formato .png y
     * el archivo de la base de datos circular .rrd. Estos scripts serán
     * lanzados desde java con el método Runtime.getRuntime().exec().
     *
     * El contenido monitorizado será almacenado en un ArrayList "info" el cúal
     * será almacenado en un fichero del directorio
     * ../rrdtool/traffic_stats/byte_rate/data_info/. Este directorio y la
     * gráfica RRDTOOL serán accedidos posteriormente desde la clase GUI_Graph
     * para así poder obtener información de la estadísticas y gráficas de
     * monitorización en tiempo real.
     *
     * Decir que este método recibe por parámetro una variable vector donde ir
     * almacenando los bytes transmitidos y recibidos de cada puerto de un
     * OVSwitch por cada muestra.
     *
     * @param byte_rate
     * @return
     */
    public long[] monitoring(long byte_rate[]) {

        //Array List donde iremos almacenando los datos y métricas monitorizadas.
        ArrayList<String> info = new ArrayList<String>();

        //Directorio del proyecto:
        File dir = new File("../API_OpenPoll");

        //Instanciación de objeto de la clase Ficheros:
        Ficheros f = new Ficheros();

        /*
        Variable donde ir almacenando los bytes transmitidos por cada muestra.
         */
        long bytes_t = 0;

        /*
        Variable donde ir almacenando los bytes recibidos por cada muestra.
         */
        long bytes_r = 0;

        /*
        Variable donde almacenar los bytes transmitidos de la anterior muestra y
        así calcular junto con los de la muestra actual (bytes_t) los bytes transmitidos
        en el intervalo de tiempo entre muestra y muestra.
         */
        long bytes_t_previous = 0;

        /*
        Variable donde almacenar los bytes recibidos de la anterior muestra y
        así calcular junto con los de la muestra actual (bytes_r) los bytes recibidos
        en el intervalo de tiempo entre muestra y muestra.
         */
        long bytes_r_previous = 0;

        bytes_t = byte_rate[0];
        bytes_r = byte_rate[1];

        try {
            //Por cada muestra vaciaremos el contenido del array list para obtener nuevos datos y métricas monitorizadas:
            info.clear();

            //Realizamos la solicitud HTTP al controlador por la API REST para obtener las métricas:
            String[] query = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes/node/openflow:" + id_sw + "/node-connector/openflow:" + id_sw + ":" + id_port + "/opendaylight-port-statistics:flow-capable-node-connector-statistics"};

            Process process1 = Runtime.getRuntime().exec(query);
            InputStream input1 = process1.getInputStream();
            BufferedInputStream buffer1 = new BufferedInputStream(input1);
            StringBuilder sb = new StringBuilder();
            int i;
            JSONObject jso = new JSONObject();

            boolean iniciojson = false;
            int cont = 0;

            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer1.read()) != -1) {

                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }

            iniciojson = false;

            buffer1.close();
            input1.close();

            bytes_r_previous = bytes_r;
            bytes_t_previous = bytes_t;

            bytes_t = 0;
            bytes_r = 0;

            try {
                /*
                    Recogemos la muestra en un JSONObject y hallaremos los campos necesarios 
                    con el método .get() para calcular las métricas:
                 */
                jso = new JSONObject(sb.toString());

                JSONObject byteStats = new JSONObject(jso.get("bytes").toString());

                //Hallamos los bytes totales recibidos y lo almacenamos en el array list:
                bytes_r = (long) ((Number) byteStats.get("received")).longValue();
                info.add("Total bytes received: " + Long.toString(bytes_r));

                //Hallamos los bytes totales transmitidos y lo almacenamos en el array list:
                bytes_t = (long) ((Number) byteStats.get("transmitted")).longValue();
                info.add("Total bytes transmitted: " + Long.toString(bytes_t));

                //Calculamos los bytes recibidos durante la muestra y lo almacenamos en el array list:
                receivedBytes = bytes_r - bytes_r_previous;
                info.add("Current bytes received: " + Long.toString(receivedBytes));

                //Calculamos los bytes transmitidos durante la muestra y lo almacenamos en el array list:
                transmittedBytes = bytes_t - bytes_t_previous;
                info.add("Current bytes transmitted: " + Long.toString(transmittedBytes));

                //Calculamos el intervalo de tiempo de la muestra y lo almacenamos en el array list:
                sample_duration = time;
                info.add("Sample duration: " + Integer.toString(sample_duration));

                JSONObject durationStats = new JSONObject(jso.get("duration").toString());

                duration_s = (long) ((Number) durationStats.get("second")).longValue();
                info.add("Duration (seconds): " + Long.toString(duration_s));

                duration_ns = (long) ((Number) durationStats.get("nanosecond")).longValue();
                info.add("Duration (nanoseconds): " + Long.toString(duration_ns));

                /*
                    Calculamos la métrica de rango de bytes recibidos durante el intervalo
                    de tiempo estimado y lo almacenamos en el array list:
                 */
                rx_byte_rate = (double) receivedBytes / sample_duration;
                info.add("Received bytes rate: " + Double.toString(rx_byte_rate));

                /*
                    Calculamos la métrica de rango de bytes transmitidos durante el intervalo
                    de tiempo estimado y lo almacenamos en el array list:
                 */
                tx_byte_rate = (double) transmittedBytes / sample_duration;
                info.add("Transmitted bytes rate: " + Double.toString(tx_byte_rate));

                /*
                    Lanzamos el script de creación y actualización de la base de datos RDDTOOL.
                    Recibirá por parámetro las métricas de bytes transmitidos y recibidos y 
                    la variable muestra_inicial.
                 */
                String[] createDatabase = {"/bin/sh", "-c", "cd " + dir.getPath() + "/rrdtool/traffic_stats/byte_rate; ./byte_rate_db.sh " + tx_byte_rate + " " + rx_byte_rate + " " + muestra_inicial + " " + "byte_rate_db_" + id_sw + "_" + id_port + ".rrd"};
                Process process2 = Runtime.getRuntime().exec(createDatabase);
                InputStream input2 = process2.getInputStream();
                BufferedInputStream buffer2 = new BufferedInputStream(input2);
                int j;

                /*while ((j = buffer2.read()) != -1) {
                        //System.out.print((char) j);
                    }*/
                input2.close();
                buffer2.close();

                /*
                    Lanzamos el script para generar la gráfica RDDTOOL con los datos de la base de datos RRDTOOL
                    actualizados.
                 */
                String[] grafico = {"/bin/sh", "-c", "cd " + dir.toString() + "/rrdtool/traffic_stats/byte_rate; ./byte_rate_graph.sh end-600s now " + "byte_rate_db_" + id_sw + "_" + id_port + ".rrd" + " " + "byte_rate_" + id_sw + "_" + id_port + ".png"};
                Process process3 = Runtime.getRuntime().exec(grafico);
                InputStream input3 = process3.getInputStream();
                BufferedInputStream buffer3 = new BufferedInputStream(input3);
                int k;

                /*while ((k = buffer3.read()) != -1) {
                        //System.out.print((char) k);
                    }*/
                input3.close();
                buffer3.close();

            } catch (JSONException e) {
                e.printStackTrace();
            }

            StringBuilder data_info = new StringBuilder();
            for (int x = 0; x < info.size(); x++) {
                data_info.append(info.get(x));
                data_info.append(System.getProperty("line.separator"));
            }

            //Escribimos en el fichero la información estadística de monitorización recogida en el arraylist:
            String fichero = "../API_OpenPoll/rrdtool/traffic_stats/byte_rate/data_info/byte_rate_" + id_sw + "_" + id_port + ".txt";
            f.escribirFichero(fichero, data_info.toString());

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
        byte_rate[0] = bytes_t;
        byte_rate[1] = bytes_r;
        return byte_rate;
    }
}
