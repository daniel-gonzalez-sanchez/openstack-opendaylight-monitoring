package api_openpoll;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;

/**
 * Clase para realizar las solicitudes por la API REST al controlador
 * OpenDayLight para monitorizar el estado de la red SDN.
 *
 * De esta forma podremos proceder a monitorizar tráfico y obtener información
 * de la red en base a métricas sobre troughput extraídas de los puertos de los
 * switches OVS.
 *
 * @author Daniel González Sánchez
 */
public class Solicitudes_API_REST extends Thread {

    /**
     * Atributo para almacenar la IP asociada al controlador para establecer la
     * conexión a la API REST del controlador OpenDayLight y poder realizar las
     * peticiones HTTP.
     */
    private String ipaddress;

    /**
     * Atributo para almacenar el puerto asociado al controlador para establecer
     * la conexión a la API REST del controlador OpenDayLight y poder realizar
     * las peticiones HTTP.
     */
    private String port;

    /**
     * Atributo con el número de puertos del switch a monitorizar.
     */
    private int num_ports_sw;

    /**
     * Atributo String con el identificador del switch OVS.
     */
    private String id_sw;

    /**
     * Atributo vector de String donde almacenaremos los identificadores de los
     * puertos del switch OVS.
     */
    private String[] list_ports;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo objeto de la clase GUI_Topology.
     */
    private GUI_Topology gt;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton stop_button;

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Constructor parametrizado.
     *
     * @param ipaddress
     * @param port
     * @param id_sw
     * @param num_ports_sw
     * @param list_ports
     * @param time
     * @param gt
     * @param stop_button
     */
    public Solicitudes_API_REST(String ipaddress, String port, int num_ports_sw, String id_sw, String[] list_ports, int time, GUI_Topology gt, JButton stop_button) {
        this.ipaddress = ipaddress;
        this.port = port;
        this.num_ports_sw = num_ports_sw;
        this.id_sw = id_sw;
        this.list_ports = list_ports;
        this.time = time;
        this.gt = gt;
        this.stop_button = stop_button;
    }

    /**
     * Hilo de ejecución para realizar las peticiones mediante la API REST al
     * controlador de las métricas de tráfico a monitorizar sobre estadísticas
     * por puerto y tablas de flujo de todos los switches pertenecientes a la
     * topología de red SDN. Se abrirá un hilo de ejecución o thread por cada
     * switch OVS.
     */
    @Override
    public void run() {

        cerrar = false;

        long ts_current_bytes[][] = new long[num_ports_sw][2];

        long ts_current_packets[][] = new long[num_ports_sw][10];

        /*
          Variable booleana para remarcar cúando se comienzan a monitorizar la métricas
          o estadísticas de puertos. 
         */
        boolean inicio = true;

        /*
          Variable para remarcar cúando se realiza la primera muestra de
          monitorización. Esta primera muestra no será correcta debido a que no
          conoceremos la que sería la muestra anterior con las métricas y por tanto 
          los cálculos de uso de puerto no serían correctos. Por ello, RRDTOOL obviará
          la primera muestra y no la recogerá en su base de datos ni la representará
          gráficamente. Esta variable será recibida en el Shell Script de creación y
          actualización de la base de datos RRD, de tal forma que para la primera 
          muestra recibirá un 1 y no actualizará la base de datos y para muestras
          posteriores recibirá un 0 indicando que ya no es la muestra inicial y por
          tanto se podrá actualizar RRD y representarse es su gráfica.
         */
        int muestra_inicial = 1;

        try {
            /*
                Mientras el usuario no cierre la GUI_Topology o GUI_Main, o no pulse
                el botón Polling de GUI_Topology, el hilo de ejecución seguirá activo:
             */
            while (cerrar == false) {

                for (int k = 0; k < num_ports_sw; k++) {
                    String[] split_id_sw = id_sw.split(":");
                    String[] new_list_ports = new String[list_ports.length];

                    for (int m = 0; m < num_ports_sw; m++) {
                        String[] split_list_port = list_ports[m].split(":");
                        new_list_ports[m] = split_list_port[2];
                    }
                    TrafficStats ts = new TrafficStats(ipaddress, port, split_id_sw[1], new_list_ports[k], time, gt, ts_current_bytes[k], ts_current_packets[k], muestra_inicial);
                    ts.monitoring();

                    ts_current_bytes[k] = ts.getCurrent_byte_rate();
                    ts_current_packets[k] = ts.getCurrent_packet_rate();
                }

                /*
                Si se trata de la muestra inicial:
                 */
                if (inicio == true) {
                    inicio = false;
                    muestra_inicial = 0;
                }

                /*
                Si pulsamos el botón Stop Polling de la GUI_Topology, se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
                 */
                stop_button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (e.getSource().equals(stop_button)) {
                            cerrar = true;
                        }
                    }
                });

                /*
                Si pulsamos la X de cierre de la GUI_Topology, se cerrará la ventana y se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
                 */
                gt.addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent evt) {
                        cerrar = true;
                    }
                });

                //Sleep para simular el tiempo de sondeo:
                Thread.sleep(time * 1000);
            }
        } catch (InterruptedException ex) {
            Logger.getLogger(Solicitudes_API_REST.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
