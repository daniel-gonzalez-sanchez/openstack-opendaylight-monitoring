package api_openpoll;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import javax.swing.JButton;

/**
 * Clase para realizar las solicitudes de estudio de consumo computacional de
 * hosts o nodos encargados del despliegue de la infraestructura de red
 * OpenStack.
 *
 * De esta forma podremos proceder a monitorizar capacidades de cómputo de los
 * hosts de gestión de la red relacionados con la carga de CPU y la utilización
 * de memoria RAM.
 *
 * @author Daniel González Sánchez
 */
public class Solicitudes_Computo extends Thread {

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo objeto de la clase GUI_Topology.
     */
    private GUI_Topology gt;

    /**
     * Atributo donde almacenar las direcciones IP de los hosts en las que vamos
     * a monitorizar la carga de CPU y el uso de RAM (%).
     */
    private ArrayList<String> ip_hosts;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton button;

    /**
     * Constructor por defecto.
     */
    public Solicitudes_Computo() {
        cerrar = false;
    }

    /**
     * Constructor parametrizado.
     *
     * @param time
     * @param ip_hosts
     * @param gt
     * @param button
     */
    public Solicitudes_Computo(int time, ArrayList<String> ip_hosts, GUI_Topology gt, JButton button) {
        this.time = time;
        this.ip_hosts = ip_hosts;
        this.gt = gt;
        this.button = button;
    }

    /**
     * Método encargado de calcular la monitorización de cómputo relacionada con
     * la carga de CPU de los hosts o nodos de la infraestructura OpenStack.
     * Recibe por parámetro el tiempo de sondeo o intervalo de tiempo entre
     * muestras en el proceso de monitorización y el arraylist con las
     * direcciones IP de los hosts en las que vamos a monitorizar la carga de
     * CPU. Instancia un objeto de la clase CPU_Load para realizar la
     * monitorización.
     *
     * @param time
     * @param ip_hosts
     */
    public void CPU_Metric(int time, ArrayList<String> ip_hosts) {
        CPU_Load cpu_load = new CPU_Load(time, ip_hosts);
        cpu_load.monitoring();
    }

    /**
     * Método encargado de calcular la monitorización de cómputo relacionada con
     * la utilización de RAM de los hosts o nodos de la infraestructura
     * OpenStack. Recibe por parámetro el tiempo de sondeo o intervalo de tiempo
     * entre muestras en el proceso de monitorización y el arraylist con las
     * direcciones IP de los hosts en las que vamos a monitorizar la utilización
     * de RAM. Instancia un objeto de la clase RAM_Usage para realizar la
     * monitorización.
     *
     * @param time
     * @param ip_hosts
     */
    public void RAM_Metric(int time, ArrayList<String> ip_hosts) {
        RAM_Usage ram_usage = new RAM_Usage(time, ip_hosts);
        ram_usage.monitoring();
    }

    /**
     * Hilo de ejecución para realizar las peticiones mediante SNMP y NRPE para
     * monitorizar métricas de consumo computacional de los host de gestión y
     * despliegue de la infraestructura de red OpenStack. 
     * Se abrirá un hilo de ejecución o thread por cada nodo de la infraestructura 
     * OpenStack.
     */
    @Override
    public void run() {
        cerrar = false;

        try {
            /*
                Mientras el usuario no cierre la GUI_Topology o GUI_Main, o no pulse
                el botón Polling de GUI_Topology, el hilo de ejecución seguirá activo:
             */
            while (cerrar == false) {

                //Monitorización de cómputo basada en carga de CPU de los hosts en la red:
                CPU_Metric(time, ip_hosts);

                //Monitorización de cómputo basada en la utilización de RAM de los hosts en la red:
                RAM_Metric(time, ip_hosts);

                /*
                Si pulsamos el botón Stop Polling de la GUI_Topology, se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
                 */
                button.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        if (e.getSource().equals(button)) {
                            cerrar = true;
                        }
                    }
                });

                /*
                Si pulsamos la X de cierre de la GUI_Graph, se cerrará la ventana y se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
                 */
                gt.addWindowListener(new WindowAdapter() {
                    public void windowClosing(WindowEvent evt) {
                        cerrar = true;
                    }
                });

                //Sleep para simular el tiempo de sondeo:
                Thread.sleep(time * 1000);
            }

        } catch (Exception e) {
            System.err.println(e);
        }
    }

}
