package api_openpoll;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 * Clase encargada de realizar operaciones relacionadas con ficheros. Dichas
 * operaciones son: creación, lectura y writer de ficheros.
 *
 * @author Daniel González Sánchez
 */
public class Ficheros {

    Scanner sc = new Scanner(System.in);

    /**
     * Método para crear fichero.
     *
     * @param filename
     */
    public void crearFichero(String filename) {
        try {
            File fichero = new File(filename);

            if (fichero.createNewFile()) {
                System.out.println("El fichero " + filename + " se ha creado.");
            }
        } catch (IOException ex) {
            System.err.println(ex);
        }
    }

    /**
     * Método para leer el contenido de un fichero de texto convencional. Se
     * encargará de ir leyendo línea a línea los datos del fichero. El método
     * recibirá por parámetro el nombre del fichero que se quiere leer. En caso
     * de que exista (ya que sería lo lógico tener preparado un fichero con
     * datos provistos), se realizará la lectura del mismo, cerrando
     * posteriormente el fichero de forma conveniente. Si no existe, se creará
     * haciendo llamada al método crearFichero().
     *
     * @param fichero
     * @return
     */
    public String leerFichero(String fichero) {
        String linea = new String();
        String c;
        File file = new File(fichero);
        if (file.exists() && !file.toString().isEmpty()) {
            try {
                BufferedReader reader = null;
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(fichero)));
                while ((c = reader.readLine()) != null) {
                    linea = linea + c + "\n";
                }
                reader.close();
            } catch (IOException e) {
                System.out.println("Error de lectura en fichero.");
            }
        } else {
            crearFichero(fichero);
            linea = new String();
        }
        return linea;
    }

    /**
     * Método que se encarga de escribir resultados en un fichero de file.
     * Primero comprobamos si existe o no el fichero. Si no existe lo crearemos
     * haciendo una llamada al método crearFichero(), y añadimos los datos
     * resultantes. Si ya existe dicho fichero, sobreescribiremos su contenido,
     * añadiendo los datos resultantes. Cerraremos convenientemente el fichero
     * de file escogido.
     *
     * @param fichero
     * @param datos
     */
    public void escribirFichero(String fichero, String datos) {
        Date d = new Date();
        File file = new File(fichero);
        if (file.exists()) {
            try {
                FileWriter writer = new FileWriter(fichero);
                writer.append(datos);
                writer.close();
            } catch (IOException ex) {
                System.err.println(ex);
            }
        } else {
            crearFichero(fichero);
            try {
                FileWriter writer = new FileWriter(fichero);
                writer.append(datos);
                writer.close();
            } catch (IOException ex) {
                System.err.println(ex);
            }
        }
    }

    /**
     * Método para leer el contenido del fichero de texto donde se almacena la
     * administración de cómputo general de los hosts vinculados a la red. Se
     * encargará de ir leyendo línea a línea los resultados de administración de
     * cómputo del fichero de file. El método recibirá por parámetro el nombre
     * del fichero que se quiere leer. En caso de que exista el fichero se
     * realizará la lectura del mismo, cerrando posteriormente el fichero de
     * forma conveniente. Si no existe, se creará haciendo llamada al método
     * crearFichero().
     *
     * @param fichero
     * @return
     */
    public ArrayList leerFicheroSNMP(String fichero) {
        String linea = new String();
        String c;
        ArrayList<String> info = new ArrayList<String>();
        File file = new File(fichero);
        if (file.exists()) {
            try {
                BufferedReader reader = null;
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(fichero)));
                while ((c = reader.readLine()) != null) {
                    info.add(c);
                }
                reader.close();
            } catch (IOException e) {
                System.out.println("Error de lectura en fichero.");
            }
        } else {
            crearFichero(fichero);
            linea = new String();
        }
        return info;
    }

    /**
     * Método para leer el contenido del fichero de texto donde se almacena la
     * carga de CPU actual de un host específico de la red. Se encargará de ir
     * leyendo la línea del fichero con la carga de CPU asociada a un host
     * específico vinculado a la infraestructura de red OpenStack. El método
     * recibirá por parámetro el nombre del fichero que se quiere leer. En caso
     * de que exista el fichero se realizará la lectura del mismo, cerrando
     * posteriormente el fichero de forma conveniente. Si no existe, se creará
     * haciendo llamada al método crearFichero().
     *
     * @param fichero
     * @return
     */
    public String leerFicheroCPU(String fichero) {
        String linea = new String();
        String c;

        File file = new File(fichero);
        if (file.exists()) {
            try {
                BufferedReader reader = null;
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(fichero)));
                while ((c = reader.readLine()) != null) {
                    if (c.startsWith("Current CPU load")) {
                        String[] split1 = c.split(": ");
                        c = split1[1];
                        linea = c + "\n";
                    }
                }
                reader.close();
            } catch (IOException e) {
                System.out.println("Error de lectura en fichero.");
            }
        } else {
            crearFichero(fichero);
            linea = new String();
        }
        return linea;
    }

    /**
     * Método para leer el contenido del fichero de texto donde se almacena el
     * uso de RAM actual de un hosts específico de la red. Se encargará de ir
     * leyendo la línea del fichero con la memoria RAM total disponible asociada
     * a un host específico vinculado a la infraestructura de red OpenStack. El
     * método recibirá por parámetro el nombre del fichero que se quiere leer.
     * En caso de que exista el fichero se realizará la lectura del mismo,
     * cerrando posteriormente el fichero de forma conveniente. Si no existe, se
     * creará haciendo llamada al método crearFichero().
     *
     * @param fichero
     * @return
     */
    public String leerFicheroRAM(String fichero) {
        String linea = new String();
        String c;

        File file = new File(fichero);
        if (file.exists()) {
            try {
                BufferedReader reader = null;
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(fichero)));
                while ((c = reader.readLine()) != null) {
                    if (c.startsWith("Total RAM unused")) {
                        String[] split1 = c.split(": ");
                        c = split1[1];
                        linea = c + "\n";
                    }
                }

                reader.close();
            } catch (IOException e) {
                System.out.println("Error de lectura en fichero.");
            }
        } else {
            crearFichero(fichero);
            linea = new String();
        }
        return linea;
    }

    /**
     * Método para leer el contenido del fichero de texto "hosts_ip.txt" que se
     * encuentra en el directorio de trabajo. Se encargará de ir leyendo las
     * líneas del fichero con las direcciones IP asociadas a los hosts
     * específicos vinculado a la infraestructura de red OpenStack. El método
     * recibirá por parámetro el nombre del fichero que se quiere leer con el
     * par definido "hostname: IP_Management" por cada host de la
     * infraestructura OpenStack que se quiera monitorizar.
     *
     * En caso de que exista el fichero (ya que sería lo lógico tener preparado
     * un fichero con las IP provistas), se realizará la lectura del mismo,
     * cerrando posteriormente el fichero de forma conveniente. Si no existe, se
     * creará haciendo llamada al método crearFichero().
     *
     * @param fichero
     * @return
     */
    public ArrayList<String> leerFicheroIPHosts(String fichero) {
        String linea = new String();
        String c;
        ArrayList<String> ip_hosts = new ArrayList<String>();
        File file = new File(fichero);
        if (file.exists() && !file.toString().isEmpty()) {
            try {
                BufferedReader reader = null;
                reader = new BufferedReader(new InputStreamReader(new FileInputStream(fichero)));
                while ((c = reader.readLine()) != null) {
                    String[] split = c.split(": ");
                    ip_hosts.add(split[1]);
                }
                reader.close();
            } catch (IOException e) {
                System.out.println("Error de lectura en fichero.");
            }
        } else {
            crearFichero(fichero);
            linea = new String();
        }
        return ip_hosts;
    }

}
