package api_openpoll;

/**
 * Clase encargada de lanzar la monitorización de la categoría Traffic
 * Statistics, basada en información extraída de puertos y tablas de flujos de
 * los switches OVS. Esta monitorización de tráfico se realiza en base a 2
 * métricas distintas: Packet Rate y Byte Rate.
 *
 * Esta clase tiene 3 métodos: uno para la monitorización basada en rango de
 * paquetes a través de un switch y un puerto concretos, otro para la
 * monitorización basada en rango de bytes a través de un switch y un puerto
 * determinados y el último que se encargará de lanzar el sondeo o
 * monitorización de tráfico de los switches datapath de la red en base a las 2
 * métricas comentadas, haciendo llamadas sucesivas a los 2 métodos anteriores.
 *
 * @author Daniel González Sánchez
 */
public class TrafficStats {

    /**
     * Atributo para almacenar la IP asociada al controlador para establecer la
     * conexión a la API REST del controlador OpenDayLight y poder realizar las
     * peticiones HTTP.
     */
    private String ipaddress;

    /**
     * Atributo para almacenar el puerto asociado al controlador para establecer
     * la conexión a la API REST del controlador OpenDayLight y poder realizar
     * las peticiones HTTP.
     */
    private String port;

    /**
     * Atributo entero donde almacenar el número del switch a monitorizar.
     */
    private String id_sw;

    /**
     * Atributo entero donde almacenar el número del puerto del switch a
     * monitorizar.
     */
    private String id_port;

    /**
     * Atributo para almacenar el tiempo de sondeo entre muestras consecutivas
     * de la métrica de monitorización. El tiempo de sondeo o polling time.
     */
    private int time;

    /**
     * Atributo para almacenar el rango de paquetes previo transmitidos y
     * recibidos durante un intervalo de tiempo.
     */
    private long previous_packet_rate[];

    /**
     * Atributo para almacenar el rango de bytes previo transmitidos y recibidos
     * durante un intervalo de tiempo.
     */
    private long previous_byte_rate[];

    /**
     * Atributo para almacenar el rango de paquetes actual transmitidos y
     * recibidos durante un intervalo de tiempo.
     */
    private long current_packet_rate[];

    /**
     * Atributo para almacenar el rango de bytes actual transmitidos y recibidos
     * durante un intervalo de tiempo.
     */
    private long current_byte_rate[];

    /**
     * Atributo booleano condición de fin de monitorización y representación
     * gráfica.
     */
    private boolean cerrar;

    /**
     * Atributo objeto de la clase GUI_Topology.
     */
    private GUI_Topology gt;

    /**
     * Variable para remarcar cúando se realiza la primera muestra de
     * monitorización. Esta primera muestra no será correcta debido a que no
     * conoceremos la que sería la muestra anterior con las métricas y por tanto
     * los cálculos de uso de puerto no serían correctos. Por ello, RRDTOOL
     * obviará la primera muestra y no la recogerá en su base de datos ni la
     * representará gráficamente. Esta variable será recibida en el Shell Script
     * de creación y actualización de la base de datos RRD, de tal forma que
     * para la primera muestra recibirá un 1 y no actualizará la base de datos y
     * para muestras posteriores recibirá un 0 indicando que ya no es la muestra
     * inicial y por tanto se podrá actualizar RRD y representarse es su
     * gráfica.
     */
    private int muestra_inicial;

    /**
     * Constructor por defecto.
     */
    public TrafficStats() {
        previous_packet_rate = new long[10];
        previous_byte_rate = new long[2];
    }

    /**
     * Constructor parametrizado.
     *
     * @param ipaddress
     * @param port
     * @param id_sw
     * @param id_port
     * @param time
     * @param gt
     * @param current_byte_rate
     * @param current_packet_rate
     * @param muestra_inicial
     */
    public TrafficStats(String ipaddress, String port, String id_sw, String id_port, int time, GUI_Topology gt, long[] current_byte_rate, long[] current_packet_rate, int muestra_inicial) {
        this.ipaddress = ipaddress;
        this.port = port;
        this.id_sw = id_sw;
        this.id_port = id_port;
        this.time = time;
        this.gt = gt;
        this.current_byte_rate = current_byte_rate;
        this.current_packet_rate = current_packet_rate;
        this.muestra_inicial = muestra_inicial;
    }

    /**
     * Para obtener el actual ratio de paquetes existentes por puerto.
     *
     * @return
     */
    public long[] getCurrent_packet_rate() {
        return current_packet_rate;
    }

    /**
     * Para modificar el actual ratio de paquetes existentes por puerto.
     *
     * @param current_packet_rate
     */
    public void setCurrent_packet_rate(long[] current_packet_rate) {
        this.current_packet_rate = current_packet_rate;
    }

    /**
     * Para obtener el actual ratio de bytes existentes por puerto.
     *
     * @return
     */
    public long[] getCurrent_byte_rate() {
        return current_byte_rate;
    }

    /**
     * Para modificar el actual ratio de bytes existentes por puerto.
     *
     * @param current_byte_rate
     */
    public void setCurrent_byte_rate(long[] current_byte_rate) {
        this.current_byte_rate = current_byte_rate;
    }

    /**
     * Método encargado de calcular las métricas de monitorización de tráfico
     * basada en rango de paquetes. Recibe por parámetro la dirección IP y
     * puerto para realizar las solicitudes HTTP al controlador a través de la
     * API REST, el tiempo de refresco de la gráfica que se genere en el proceso
     * de monitorización y el número de switch y su puerto a monitorizar, la
     * condición de muestreo inicial y el rango de bytes transcurridos en cada
     * instante. Instancia un objeto de la clase PacketRate para realizar la
     * monitorización.
     *
     * @param ipaddress
     * @param port
     * @param time
     * @param id_sw
     * @param id_port
     * @param muestra_inicial
     * @param p_packet_rate
     */
    public void PacketRate(String ipaddress, String port, int time, String id_sw, String id_port, int muestra_inicial, long p_packet_rate[]) {
        PacketRate pr = new PacketRate(ipaddress, port, time, id_sw, id_port, muestra_inicial);
        current_packet_rate = pr.monitoring(p_packet_rate);
    }

    /**
     * Método encargado de calcular las métricas de monitorización de tráfico
     * basada en rango de bytes. Recibe por parámetro la dirección IP y puerto
     * para realizar las solicitudes HTTP al controlador a través de la API
     * REST, el tiempo de refresco de la gráfica que se genere en el proceso de
     * monitorización, el número de switch y su puerto a monitorizar, la
     * condición de muestreo inicial y el rango de bytes transcurridos en cada
     * instante. Instancia un objeto de la clase ByteRate para realizar la
     * monitorización.
     *
     * @param ipaddress
     * @param port
     * @param time
     * @param id_sw
     * @param id_port
     * @param muestra_inicial
     * @param p_byte_rate
     */
    public void ByteRate(String ipaddress, String port, int time, String id_sw, String id_port, int muestra_inicial, long p_byte_rate[]) {
        ByteRate br = new ByteRate(ipaddress, port, time, id_sw, id_port, muestra_inicial);
        current_byte_rate = br.monitoring(p_byte_rate);
    }

    /**
     * Método que se encarga de lanzar la monitorización de tráfico basada en
     * los puertos de los switches de la red haciendo llamadas sucesivas a los 2
     * métodos siguientes: PacketRate() y ByteRate()
     */
    public void monitoring() {

        previous_packet_rate = new long[10];
        previous_byte_rate = new long[2];

        for (int i = 0; i < 10; i++) {
            previous_packet_rate[i] = 0;
        }

        for (int i = 0; i < 2; i++) {
            previous_byte_rate[i] = 0;
        }

        for (int j = 0; j < 10; j++) {
            previous_packet_rate[j] = current_packet_rate[j];
        }

        for (int j = 0; j < 2; j++) {
            previous_byte_rate[j] = current_byte_rate[j];
        }

        //Monitorización basada en rango de paquetes por puerto del switch:
        PacketRate(ipaddress, port, time, id_sw, id_port, muestra_inicial, previous_packet_rate);
        //Monitorización basada en rango de bytes por puerto del switch:
        ByteRate(ipaddress, port, time, id_sw, id_port, muestra_inicial, previous_byte_rate);

    }

}
