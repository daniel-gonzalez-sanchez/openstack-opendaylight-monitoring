package api_openpoll;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JTextArea;

/**
 * Clase con el hilo de ejecución que se se encarga de refrescar las
 * estadísticas o métricas monitorizadas de la red representadas en el
 * JScrollPane de la GUI_Graph correspondiente.
 *
 * @author Daniel González Sánchez
 */
public class InfoStats extends Thread {

    /**
     * Atributo para almacenar el tiempo de refresco que tendrá la gráfica de
     * monitorización para que se vaya actualizando. El tiempo de refresco o
     * refresh time.
     */
    private int time;

    /**
     * Atributo con el path del fichero donde almacenar las estadísticas de
     * información sobre monitorización de la red.
     */
    private String file;

    /**
     * Atributo objeto de la clase JTextArea.
     */
    private JTextArea jtx;

    /**
     * Atributo objeto de la clase Ficheros.
     */
    private Ficheros f;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton btStopData;

    /**
     * Atributo objeto de la clase JButton.
     */
    private JButton btStopPoll;

    /**
     * Atrubuto objeto de la clase GUI_Graph.
     */
    private GUI_Graph graph;

    /**
     * Atributo booleano condición de fin de monitorización.
     */
    private boolean cerrar;

    /**
     * Constructor parametrizado.
     *
     * @param time
     * @param jtx
     * @param btStopData
     * @param file
     * @param graph
     * @param btStopPoll
     */
    public InfoStats(int time, JTextArea jtx, JButton btStopData, String file, GUI_Graph graph, JButton btStopPoll) {
        this.time = time;
        this.jtx = jtx;
        this.btStopData = btStopData;
        this.file = file;
        this.graph = graph;
        this.btStopPoll = btStopPoll;
    }

    @Override
    public void run() {

        f = new Ficheros();
        cerrar = false;
        while (cerrar == false) {
            String datos = f.leerFichero(file);
            jtx.setText("");
            jtx.append(datos);
            jtx.setCaretPosition(0);

            /*
                Si se pulsa el botón Stop Polling de la GUI_Topology, se cerrará la ventana y se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
             */
            btStopPoll.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource().equals(btStopPoll)) {
                        cerrar = true;
                    }
                }
            });

            /*
                Si pulsamos el botón Stop Data de la GUI_Graph, se borrará el JLabel de la GUI y se dejarán de
                mostrar los datos de la de monitorización de información determinada parando el hilo de ejecución (cerrar = true).
             */
            btStopData.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (e.getSource().equals(btStopData)) {
                        cerrar = true;
                    }
                }
            });

            /*
                Si pulsamos la X de cierre de la GUI_Graph, se cerrará la ventana y se dejará de
                monitorizar información parando el hilo de ejecución (cerrar = true).
             */
            graph.addWindowListener(new WindowAdapter() {
                public void windowClosing(WindowEvent evt) {
                    cerrar = true;
                }
            });

            try {
                //Sleep para simular el tiempo de refresco:
                Thread.sleep(time * 1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(InfoStats.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
