package api_openpoll;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Esta clase se encarga de realizar peticiones, relacionadas con estadísticas
 * de los switches de la red, al controlador mediante la API REST de
 * OpenDAyLight (a través de la NorthBound Interface SDN).
 *
 * Tiene un método para determinar el número de switches OVS y puertos asociados
 * de la topología de los que monitorizaremos diferentes datos de tráfico.
 *
 * @author Daniel González Sánchez
 */
public class SwitchStats {

    /**
     * Atributo para almacenar el número de switches existentes en la red.
     */
    private int num_switches;

    /**
     * Atributo vector de Strings con la lista de switches existentes en la
     * topología de red.
     */
    private String[] list_switches;

    /**
     * Atributo vector donde almacenaremos el número de puertos de cada switch
     * de nuestra topología.
     */
    private String[] num_ports_switches;

    /**
     * Atributo vector donde almacenaremos el nombre del puerto asociado a cada
     * puerto de un switch de nuestra topología.
     */
    private String[][] name_ports_switches;

    /**
     * Atributo matriz donde almacenaremos la lista de números o identificadores
     * de puertos asociados a cada uno de los switches de nuestra topología.
     */
    private String[][] list_ports;

    /**
     * Constructor por defecto.
     */
    public SwitchStats() {
        num_switches = 0;
        list_switches = new String[100];
        num_ports_switches = new String[100];
        name_ports_switches = new String[100][100];
        list_ports = new String[100][100];
    }

    /**
     * Constructor parametrizado.
     *
     * @param num_switches
     * @param list_switches
     * @param num_ports_switches
     * @param name_ports_switches
     * @param list_ports
     */
    public SwitchStats(int num_switches, String[] list_switches, String[] num_ports_switches, String[][] name_ports_switches, String[][] list_ports) {
        this.num_switches = num_switches;
        this.list_switches = list_switches;
        this.num_ports_switches = num_ports_switches;
        this.name_ports_switches = name_ports_switches;
        this.list_ports = list_ports;
    }

    /**
     * Para obtener el número de switches existentes.
     *
     * @return
     */
    public int getNum_switches() {
        return num_switches;
    }

    /**
     * Para modificar el número de switches.
     *
     * @param num_switches
     */
    public void setNum_switches(int num_switches) {
        this.num_switches = num_switches;
    }

    /**
     * Para obtener la lista de switches (identificadores de los switches).
     *
     * @return
     */
    public String[] getList_switches() {
        return list_switches;
    }

    /**
     * Para modificar la lista de switches (identificadores de los switches).
     *
     * @param list_switches
     */
    public void setList_switches(String[] list_switches) {
        this.list_switches = list_switches;
    }

    /**
     * Para obtener el número puertos de un switch.
     *
     * @return
     */
    public String[] getNum_ports_switches() {
        return num_ports_switches;
    }

    /**
     * Para modificar el número de puertos de un switch.
     *
     * @param num_ports_switches
     */
    public void setNum_ports_switches(String[] num_ports_switches) {
        this.num_ports_switches = num_ports_switches;
    }

    /**
     * Para obtener el nombre de los puertos de los switches.
     *
     * @return
     */
    public String[][] getName_ports_switches() {
        return name_ports_switches;
    }

    /**
     * Para modificar el nombre de los puertos de los switches.
     *
     * @param name_ports_switches
     */
    public void setName_ports_switches(String[][] name_ports_switches) {
        this.name_ports_switches = name_ports_switches;
    }

    /**
     * Para obtener la lista de los puertos de los switches (números o
     * identificadores de los puertos).
     *
     * @return
     */
    public String[][] getList_ports() {
        return list_ports;
    }

    /**
     * Para modificar la lista de los puertos de los switches (números o
     * identificadores de los puertos).
     *
     * @param list_ports
     */
    public void setList_ports(String[][] list_ports) {
        this.list_ports = list_ports;
    }

    /**
     * Este método se encarga de realizar una solicitud HTTP al controlador a
     * través de la API REST para obtener el número de switches OVS existentes
     * en la topología de red, así como los identificadores de switches y
     * puertos asociados. Este método será llamado desde la clase GUI_Main para
     * detectar los switches OVS de la topología para que posteriormente puedan
     * ser monitorizados. El método recibe por parámetro la dirección IP y el
     * puerto del controlador necesarios para realizar las peticiones HTTP.
     *
     * La petición HTTP a través de la API REST se realiza lanzando un comando
     * Linux a través de Java con el método Runtime.getRuntime().exec().
     *
     * La petición en ese caso es la siguiente: curl -u "admin:admin" -H
     * "Accept: application/json" -H "Content-type: application/json" -X GET
     * "http://{ipaddress}:{port}/restconf/operational/opendaylight-inventory:nodes.
     *
     * Desde un buffer recogeremos la información proporcionada al realizar la
     * petición. Los datos de la respuesta son generados como objetos tipo JSON
     * propio de JavaScript. Filtraremos el número de switches existentes.
     *
     * @param ipaddress
     * @param port
     */
    public void discoverTopology(String ipaddress, String port) {
        try {
            String[] request = {"curl", "-u", "admin:admin", "-H", "Accept: application/json", "-H", "Content-type:  application/json", "-X", "GET", "http://" + ipaddress + ":" + port + "/restconf/operational/opendaylight-inventory:nodes"};
            Process process = Runtime.getRuntime().exec(request);
            InputStream input = process.getInputStream();
            BufferedInputStream buffer = new BufferedInputStream(input);
            StringBuilder sb = new StringBuilder();

            int i;
            boolean iniciojson = false;
            int cont = 0;

            /*
            Con el buffer recogemos los datos recibidos de la solicitud.
            Los datos vendrán contenidos en un Objeto de tipo JSON.
             */
            while ((i = buffer.read()) != -1) {
                if ((char) i == '{') {
                    cont++;
                }
                if (cont == 2) {
                    iniciojson = true;
                }
                if (iniciojson == true) {
                    sb.append((char) i);
                }
            }
            iniciojson = false;

            buffer.close();
            input.close();

            String switches_stats = sb.toString();

            StringBuilder sb2 = new StringBuilder();

            try {

                /*
                Recogemos la información en un JSONObject y hallaremos los datos necesarios 
                con el método .get():
                 */
                JSONObject jsonobj = new JSONObject(switches_stats);

                JSONArray nodes = new JSONArray(jsonobj.get("node").toString());
                num_switches = nodes.length();
                list_switches = new String[nodes.length()];
                num_ports_switches = new String[nodes.length()];
                for (int j = 0; j < nodes.length(); j++) {
                    JSONObject node = new JSONObject(nodes.getJSONObject(j).toString());
                    list_switches[j] = node.get("id").toString();

                    JSONArray node_connector = new JSONArray(node.get("node-connector").toString());

                    num_ports_switches[j] = Integer.toString(node_connector.length());
                    for (int k = 0; k < node_connector.length(); k++) {
                        JSONObject connector = new JSONObject(node_connector.getJSONObject(k).toString());
                        name_ports_switches[j][k] = connector.get("flow-node-inventory:name").toString();
                        list_ports[j][k] = connector.get("id").toString();
                    }
                }

            } catch (JSONException e) {
                System.err.println(e);
                e.printStackTrace();
            }

        } catch (Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
    }
}
